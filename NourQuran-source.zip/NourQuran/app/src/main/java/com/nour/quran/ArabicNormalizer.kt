package com.nour.quran

import java.util.Locale

/**
 * تطبيع النص العربي قبل تحليله.
 * يزيل التشكيل والتطويل والرموز والإيموجي، ويوحّد أشكال الحروف المتشابهة،
 * حتى تتطابق الجمل المكتوبة بأكثر من طريقة.
 */
object ArabicNormalizer {

    private val markOrTatweel = Regex("[\\p{M}\\u0640]")
    private val notWordChar = Regex("[^\\p{L}\\p{N}\\s]")
    private val spaces = Regex("\\s+")

    /** النص بعد التنظيف الكامل، مناسب للمقارنة والبحث. */
    fun normalize(input: String): String {
        var value = input.lowercase(Locale.ROOT)
        value = markOrTatweel.replace(value, "")
        value = value
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ٱ', 'ا')
            .replace('ى', 'ي').replace('ئ', 'ي').replace('ؤ', 'و').replace('ة', 'ه')
        value = notWordChar.replace(value, " ")
        return spaces.replace(value, " ").trim()
    }

    /** تقسيم النص المنظف إلى كلمات. */
    fun tokens(input: String): List<String> {
        val value = normalize(input)
        return if (value.isEmpty()) emptyList() else value.split(' ')
    }

    /** إزالة أداة التعريف «ال» من الكلمات الطويلة، مثل: الواتساب ← واتساب. */
    fun stripDefiniteArticle(token: String): String =
        if (token.length > 3 && token.startsWith("ال")) token.substring(2) else token

    /** مسافة ليفنشتاين بين كلمتين، لتحمل الأخطاء الإملائية البسيطة. */
    fun editDistance(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)
        for (i in 1..a.length) {
            current[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                current[j] = minOf(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + cost)
            }
            val swap = previous
            previous = current
            current = swap
        }
        return previous[b.length]
    }
}
