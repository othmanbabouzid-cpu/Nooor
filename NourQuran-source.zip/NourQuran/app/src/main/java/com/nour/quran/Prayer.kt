package com.nour.quran

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class PrayerDay(val date: String, val times: Map<String, String>)

object PrayerNames {
    val ALL: List<String> = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")

    private val AR: Map<String, String> = mapOf(
        "Fajr" to "الفجر",
        "Dhuhr" to "الظهر",
        "Asr" to "العصر",
        "Maghrib" to "المغرب",
        "Isha" to "العشاء"
    )

    fun arabic(name: String): String = AR[name] ?: name
}

object Methods {
    /** طرق الحساب المتاحة في Aladhan. الفتوى المغربية الرسمية قد تختلف قليلًا عن الحسابات. */
    val list: List<Pair<Int, String>> = listOf(
        3 to "رابطة العالم الإسلامي",
        4 to "أم القرى",
        5 to "الهيئة المصرية",
        2 to "ISNA"
    )

    fun label(id: Int): String = list.firstOrNull { it.first == id }?.second ?: "طريقة $id"
}

object PrayerApi {

    /** يجلب أوقات شهر كامل. school=0 يعني حساب العصر بالظل العادي، كما عند المالكية والشافعية. */
    fun fetchMonth(lat: Double, lng: Double, method: Int, year: Int, month: Int): List<PrayerDay> {
        val url = Endpoints.ALADHAN + "/calendar/$year/$month" +
            "?latitude=" + format(lat) + "&longitude=" + format(lng) +
            "&method=$method&school=0"
        val arr = JSONObject(Net.get(url)).getJSONArray("data")
        return (0 until arr.length()).map { i ->
            val item = arr.getJSONObject(i)
            val timings = item.getJSONObject("timings")
            // التاريخ يأتي dd-MM-yyyy فنحوّله إلى yyyy-MM-dd
            val parts = item.getJSONObject("date").getJSONObject("gregorian").getString("date").split("-")
            val iso = parts[2] + "-" + parts[1] + "-" + parts[0]
            val times = PrayerNames.ALL.associateWith { name ->
                timings.getString(name).substringBefore(' ')
            }
            PrayerDay(iso, times)
        }
    }

    private fun format(v: Double): String = String.format(Locale.US, "%.4f", v)
}

object PrayerCache {

    data class Cache(val key: String, val days: List<PrayerDay>)

    /** مفتاح الكاش: يتغير مع الموقع والطريقة والمنطقة الزمنية، فيُعاد الجلب. */
    fun key(c: Context): String =
        "${Prefs.lat(c)},${Prefs.lng(c)},${Prefs.method(c)},${java.util.TimeZone.getDefault().id}"

    fun load(c: Context): Cache {
        val raw = Prefs.cacheJson(c) ?: return Cache("", emptyList())
        return try {
            val root = JSONObject(raw)
            val arr = root.getJSONArray("days")
            val days = (0 until arr.length()).map { i ->
                val d = arr.getJSONObject(i)
                val t = d.getJSONObject("t")
                PrayerDay(d.getString("d"), PrayerNames.ALL.associateWith { name -> t.getString(name) })
            }
            Cache(root.getString("key"), days)
        } catch (_: Exception) {
            Cache("", emptyList())
        }
    }

    fun save(c: Context, key: String, days: List<PrayerDay>) {
        val arr = JSONArray()
        for (day in days) {
            val t = JSONObject()
            for ((name, time) in day.times) t.put(name, time)
            arr.put(JSONObject().put("d", day.date).put("t", t))
        }
        Prefs.setCacheJson(c, JSONObject().put("key", key).put("days", arr).toString())
    }

    /** أقرب وقت مستقبلي لصلاة معينة. */
    fun nextTime(days: List<PrayerDay>, name: String, now: Long): Long? {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        var best: Long? = null
        for (day in days) {
            val hhmm = day.times[name] ?: continue
            val t = runCatching { fmt.parse(day.date + " " + hhmm)?.time }.getOrNull() ?: continue
            if (t > now + 1000L) {
                val current = best
                if (current == null || t < current) best = t
            }
        }
        return best
    }

    /** الصلاة القادمة أيًا كانت، مع وقتها. */
    fun nextPrayer(days: List<PrayerDay>, now: Long): Pair<String, Long>? {
        var best: Pair<String, Long>? = null
        for (name in PrayerNames.ALL) {
            val t = nextTime(days, name, now) ?: continue
            val current = best
            if (current == null || t < current.second) best = Pair(name, t)
        }
        return best
    }

    fun clock(millis: Long): String = SimpleDateFormat("HH:mm", Locale.US).format(Date(millis))
}
