package com.nour.quran

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class SurahInfo(
    val number: Int,
    val name: String,
    val english: String,
    val ayahCount: Int,
    val revelation: String
)

data class Ayah(val number: Int, val text: String)

data class DailyAyah(val surahNumber: Int, val surahName: String, val numberInSurah: Int, val text: String)

object Dates {
    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
}

object Editions {
    /**
     * مفتاح داخلي ← معرّف النسخة في alquran.cloud.
     * معرّف ورش «ar.warsh» غير مُتحقَّق منه؛ قبل الاعتماد عليه تأكد من محتواه.
     */
    val text: List<Pair<String, String>> = listOf(
        "hafs" to "quran-uthmani",
        "warsh" to "ar.warsh"
    )

    fun textId(key: String): String = text.firstOrNull { it.first == key }?.second ?: "quran-uthmani"

    fun label(key: String): String = when (key) {
        "warsh" -> "ورش عن نافع (تجريبي)"
        else -> "حفص عن عاصم"
    }
}

object TafsirSources {
    val list: List<Pair<String, String>> = listOf(
        "none" to "بدون تفسير",
        "muyassar" to "التفسير الميسر",
        "qurtubi" to "تفسير القرطبي (مؤلفه مالكي المذهب)"
    )

    fun label(key: String): String = list.firstOrNull { it.first == key }?.second ?: "بدون تفسير"
}

object Reciters {
    const val DEFAULT = "Alafasy_128kbps"

    /** قراء حفص: مجلدات everyayah.com ← الاسم. تحقّق من المجلدات قبل النشر. */
    private val hafsList: List<Pair<String, String>> = listOf(
        "Alafasy_128kbps" to "مشاري العفاسي",
        "Husary_128kbps" to "محمود خليل الحصري",
        "Minshawy_Murattal_128kbps" to "محمد صديق المنشاوي"
    )

    /**
     * قراء ورش: قائمة فارغة عمدًا. لم أتحقق من مجلد ورش على everyayah.com،
     * ولذلك لا يُشغَّل أي قارئ حفص عند اختيار رواية ورش.
     */
    private val warshList: List<Pair<String, String>> = emptyList()

    private val allReciters: List<Pair<String, String>> = hafsList + warshList

    /** القراء المسموح باختيارهم لكل رواية. */
    fun forRiwaya(edition: String): List<Pair<String, String>> = if (edition == "warsh") warshList else hafsList

    fun defaultFor(edition: String): String = forRiwaya(edition).firstOrNull()?.first ?: ""

    fun label(folder: String): String {
        if (folder.isEmpty()) return "لا يوجد قارئ"
        return allReciters.firstOrNull { it.first == folder }?.second ?: folder
    }

    /** رابط صوت آية: السورة والآية بثلاث خانات لكل منهما. */
    fun url(folder: String, surah: Int, ayah: Int): String =
        Endpoints.EVERYAYAH + "/" + folder + "/" + String.format("%03d%03d.mp3", surah, ayah)
}

/** حجم المحفوظ على الهاتف، وحذف الصوت وحده مع بقاء النص. */
object OfflineStore {
    fun isTextCached(c: Context, edition: String, surah: Int): Boolean =
        File(c.filesDir, "text/$edition/$surah.json").exists()

    fun textCount(c: Context, edition: String): Int =
        File(c.filesDir, "text/$edition").listFiles()?.count { it.name.endsWith(".json") } ?: 0

    fun sizeBytes(c: Context): Long = dirSize(File(c.filesDir, "text")) + dirSize(File(c.filesDir, "audio"))

    fun clearAudio(c: Context) {
        File(c.filesDir, "audio").deleteRecursively()
    }

    private fun dirSize(dir: File): Long {
        if (!dir.exists()) return 0L
        return dir.walkTopDown().filter { it.isFile }.fold(0L) { acc, f -> acc + f.length() }
    }
}

object QuranRepository {

    private const val TOTAL_AYAHS = 6236
    private const val DAY_MS = 86400000L

    fun parseAyahs(raw: String): List<Ayah> {
        val arr = JSONObject(raw).getJSONObject("data").getJSONArray("ayahs")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Ayah(o.getInt("numberInSurah"), o.getString("text"))
        }
    }

    fun surahList(c: Context): List<SurahInfo> {
        val file = File(c.filesDir, "surahs.json")
        val raw = if (file.exists()) {
            file.readText()
        } else {
            val fetched = Net.get(Endpoints.ALQURAN + "/surah")
            file.writeText(fetched)
            fetched
        }
        val arr = JSONObject(raw).getJSONArray("data")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            SurahInfo(
                o.getInt("number"),
                o.getString("name"),
                o.getString("englishName"),
                o.getInt("numberOfAyahs"),
                o.getString("revelationType")
            )
        }
    }

    fun surah(c: Context, edition: String, number: Int): List<Ayah> =
        parseAyahs(
            cachedGet(c, "text/$edition/$number.json", Endpoints.ALQURAN + "/surah/$number/" + Editions.textId(edition))
        )

    /** تفسير السورة: قائمة بنص كل آية. */
    fun tafsir(c: Context, source: String, number: Int): List<String> = when (source) {
        "muyassar" -> parseAyahs(
            cachedGet(c, "tafsir/muyassar/$number.json", Endpoints.ALQURAN + "/surah/$number/ar.muyassar")
        ).map { it.text }
        "qurtubi" -> parseTafsirFile(
            cachedGet(c, "tafsir/qurtubi/$number.json", Endpoints.TAFSIR_CDN + "/ar-tafseer-al-qurtubi/$number.json")
        )
        else -> emptyList()
    }

    /** شكل ملف التفسير غير مُتحقَّق منه بالكامل، لذلك يقبل أكثر من شكل معقول. */
    private fun parseTafsirFile(raw: String): List<String> {
        val arr: JSONArray = if (raw.trimStart().startsWith("[")) {
            JSONArray(raw)
        } else {
            findArray(JSONObject(raw)) ?: throw IllegalStateException("شكل ملف التفسير غير معروف")
        }
        return (0 until arr.length()).map { i ->
            when (val item = arr.opt(i)) {
                is JSONObject -> item.optString("text", "")
                is String -> item
                else -> ""
            }
        }
    }

    private fun findArray(o: JSONObject): JSONArray? {
        val names = o.keys()
        while (names.hasNext()) {
            val key = names.next().toString()
            when (val value = o.opt(key)) {
                is JSONArray -> return value
                is JSONObject -> {
                    val nested = findArray(value)
                    if (nested != null) return nested
                }
            }
        }
        return null
    }

    /** آية اليوم. ترتيب الآيات يُخلط بضرب في عدد يقع أوليًا مع 6236 حتى لا تكون متتابعة. */
    fun dailyIndex(): Int {
        val now = System.currentTimeMillis()
        val localMillis = now + TimeZone.getDefault().getOffset(now)
        val day = localMillis / DAY_MS
        return ((day * 7L) % TOTAL_AYAHS).toInt() + 1
    }

    fun dailyAyah(c: Context, edition: String): DailyAyah {
        val stamp = Dates.today() + "|" + edition
        val cached = Prefs.dailyJson(c)
        if (Prefs.dailyStamp(c) == stamp && cached != null) return dailyFromJson(cached)

        val raw = Net.get(Endpoints.ALQURAN + "/ayah/" + dailyIndex() + "/" + Editions.textId(edition))
        val data = JSONObject(raw).getJSONObject("data")
        val surah = data.getJSONObject("surah")
        val result = DailyAyah(
            surah.getInt("number"),
            surah.getString("name"),
            data.getInt("numberInSurah"),
            data.getString("text")
        )
        Prefs.setDaily(c, stamp, dailyToJson(result))
        return result
    }

    /** آية اليوم من الكاش فقط، ولا تُرجع شيئًا إن لم تكن محمّلة لليوم الحالي. */
    fun cachedDaily(c: Context): DailyAyah? {
        val json = Prefs.dailyJson(c) ?: return null
        return try {
            dailyFromJson(json)
        } catch (_: Exception) {
            null
        }
    }

    private fun dailyToJson(d: DailyAyah): String =
        JSONObject()
            .put("s", d.surahNumber)
            .put("n", d.surahName)
            .put("a", d.numberInSurah)
            .put("t", d.text)
            .toString()

    private fun dailyFromJson(raw: String): DailyAyah {
        val o = JSONObject(raw)
        return DailyAyah(o.getInt("s"), o.getString("n"), o.getInt("a"), o.getString("t"))
    }

    /** يحمّل كل سور النسخة المختارة للقراءة بدون نت. */
    fun downloadAll(c: Context, edition: String, progress: (Int) -> Unit) {
        for (n in 1..114) {
            surah(c, edition, n)
            progress(n)
        }
    }

    private fun cachedGet(c: Context, relative: String, url: String): String {
        val file = File(c.filesDir, relative)
        if (file.exists()) return file.readText()
        val raw = Net.get(url)
        val dir = file.parentFile
        if (dir != null) dir.mkdirs()
        file.writeText(raw)
        return raw
    }
}
