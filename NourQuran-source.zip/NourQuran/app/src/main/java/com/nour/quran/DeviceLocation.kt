package com.nour.quran

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager

object DeviceLocation {

    /** يأخذ آخر موقع معروف ويحفظه. يرجع false إذا لم يتوفر موقع أو لا توجد صلاحية. */
    fun update(c: Context): Boolean {
        if (c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return false
        }
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER, LocationManager.GPS_PROVIDER)
        for (provider in providers) {
            val location = try {
                lm.getLastKnownLocation(provider)
            } catch (_: Exception) {
                null
            }
            if (location != null) {
                Prefs.setLocation(c, location.latitude, location.longitude)
                return true
            }
        }
        return false
    }
}
