package com.nour.quran

import android.content.Context

object Prefs {
    private const val FILE = "nour_prefs"

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ---- القراءة ----
    fun edition(c: Context): String = sp(c).getString("edition", "hafs") ?: "hafs"
    fun setEdition(c: Context, v: String) = sp(c).edit().putString("edition", v).apply()

    fun reciter(c: Context): String = sp(c).getString("reciter", Reciters.DEFAULT) ?: Reciters.DEFAULT
    fun setReciter(c: Context, v: String) = sp(c).edit().putString("reciter", v).apply()

    fun tafsirSource(c: Context): String = sp(c).getString("tafsir", "none") ?: "none"
    fun setTafsirSource(c: Context, v: String) = sp(c).edit().putString("tafsir", v).apply()

    fun hadithCollection(c: Context): String = sp(c).getString("hadith", "malik") ?: "malik"
    fun setHadithCollection(c: Context, v: String) = sp(c).edit().putString("hadith", v).apply()

    fun fontSize(c: Context): Int = sp(c).getInt("font", 1)
    fun setFontSize(c: Context, v: Int) = sp(c).edit().putInt("font", v).apply()

    /** 0 مضغوط، 1 عادي، 2 واسع. */
    fun lineSpacing(c: Context): Int = sp(c).getInt("spacing", 1)
    fun setLineSpacing(c: Context, v: Int) = sp(c).edit().putInt("spacing", v).apply()

    fun nightMode(c: Context): Boolean = sp(c).getBoolean("night", true)
    fun setNightMode(c: Context, v: Boolean) = sp(c).edit().putBoolean("night", v).apply()

    fun repeatCount(c: Context): Int = sp(c).getInt("repeat", 1)
    fun setRepeatCount(c: Context, v: Int) = sp(c).edit().putInt("repeat", v).apply()

    fun autoNext(c: Context): Boolean = sp(c).getBoolean("autonext", false)
    fun setAutoNext(c: Context, v: Boolean) = sp(c).edit().putBoolean("autonext", v).apply()

    fun lastRead(c: Context): Pair<Int, Int>? {
        val surah = sp(c).getInt("last_surah", 0)
        if (surah == 0) return null
        return Pair(surah, sp(c).getInt("last_ayah", 1))
    }

    fun setLastRead(c: Context, surah: Int, ayah: Int) {
        sp(c).edit().putInt("last_surah", surah).putInt("last_ayah", ayah).apply()
    }

    /** العلامات المرجعية بصيغة «سورة:آية». */
    fun bookmarks(c: Context): Set<String> = HashSet(sp(c).getStringSet("bookmarks", emptySet()) ?: emptySet())
    fun setBookmarks(c: Context, v: Set<String>) = sp(c).edit().putStringSet("bookmarks", HashSet(v)).apply()

    // ---- الصلاة ----
    fun method(c: Context): Int = sp(c).getInt("method", 3)
    fun setMethod(c: Context, v: Int) = sp(c).edit().putInt("method", v).apply()

    /** الإحداثيات الافتراضية: الدار البيضاء، وتتغير عند تحديث الموقع. */
    fun lat(c: Context): Double = sp(c).getFloat("lat", 33.5731f).toDouble()
    fun lng(c: Context): Double = sp(c).getFloat("lng", -7.5898f).toDouble()
    fun setLocation(c: Context, lat: Double, lng: Double) {
        sp(c).edit().putFloat("lat", lat.toFloat()).putFloat("lng", lng.toFloat()).apply()
    }

    fun prayerEnabled(c: Context, name: String): Boolean = sp(c).getBoolean("prayer_$name", true)
    fun setPrayerEnabled(c: Context, name: String, v: Boolean) =
        sp(c).edit().putBoolean("prayer_$name", v).apply()

    /** وضع التنبيه لكل صلاة: 0 صوت، 1 اهتزاز، 2 صامت. */
    fun prayerMode(c: Context, name: String): Int = sp(c).getInt("pmode_$name", 0)
    fun setPrayerMode(c: Context, name: String, v: Int) = sp(c).edit().putInt("pmode_$name", v).apply()

    /** تنبيه مسبق بعدد الدقائق، و0 يعني بدون. */
    fun preMinutes(c: Context): Int = sp(c).getInt("pre_min", 0)
    fun setPreMinutes(c: Context, v: Int) = sp(c).edit().putInt("pre_min", v).apply()

    /** تعديل التاريخ الهجري بالأيام: -1 أو 0 أو +1. */
    fun hijriOffset(c: Context): Int = sp(c).getInt("hijri_off", 0)
    fun setHijriOffset(c: Context, v: Int) = sp(c).edit().putInt("hijri_off", v).apply()

    fun cacheJson(c: Context): String? = sp(c).getString("prayer_cache", null)
    fun setCacheJson(c: Context, v: String) = sp(c).edit().putString("prayer_cache", v).apply()

    // ---- آية اليوم والأذكار ----
    fun dailyStamp(c: Context): String? = sp(c).getString("daily_stamp", null)
    fun dailyJson(c: Context): String? = sp(c).getString("daily_json", null)
    fun setDaily(c: Context, stamp: String, json: String) {
        sp(c).edit().putString("daily_stamp", stamp).putString("daily_json", json).apply()
    }

    fun dhikrCount(c: Context, id: String): Int = sp(c).getInt("dhikr_$id", 0)
    fun setDhikrCount(c: Context, id: String, v: Int) = sp(c).edit().putInt("dhikr_$id", v).apply()
}
