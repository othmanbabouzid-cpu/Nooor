package com.nour.quran

import android.content.Context

object Prefs {
    private const val FILE = "nour_prefs"

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun edition(c: Context): String = sp(c).getString("edition", "hafs") ?: "hafs"
    fun setEdition(c: Context, v: String) = sp(c).edit().putString("edition", v).apply()

    fun reciter(c: Context): String = sp(c).getString("reciter", Reciters.DEFAULT) ?: Reciters.DEFAULT
    fun setReciter(c: Context, v: String) = sp(c).edit().putString("reciter", v).apply()

    fun tafsirSource(c: Context): String = sp(c).getString("tafsir", "none") ?: "none"
    fun setTafsirSource(c: Context, v: String) = sp(c).edit().putString("tafsir", v).apply()

    fun hadithCollection(c: Context): String = sp(c).getString("hadith", "malik") ?: "malik"
    fun setHadithCollection(c: Context, v: String) = sp(c).edit().putString("hadith", v).apply()

    /** 0 صغير، 1 متوسط، 2 كبير. */
    fun fontSize(c: Context): Int = sp(c).getInt("font", 1)
    fun setFontSize(c: Context, v: Int) = sp(c).edit().putInt("font", v).apply()

    fun method(c: Context): Int = sp(c).getInt("method", 3)
    fun setMethod(c: Context, v: Int) = sp(c).edit().putInt("method", v).apply()

    /** الإحداثيات الافتراضية: الدار البيضاء، وتتغير عند تحديث الموقع. */
    fun lat(c: Context): Double = sp(c).getFloat("lat", 33.5731f).toDouble()
    fun lng(c: Context): Double = sp(c).getFloat("lng", -7.5898f).toDouble()
    fun setLocation(c: Context, lat: Double, lng: Double) {
        sp(c).edit().putFloat("lat", lat.toFloat()).putFloat("lng", lng.toFloat()).apply()
    }

    fun prayerEnabled(c: Context, name: String): Boolean = sp(c).getBoolean("prayer_$name", true)
    fun setPrayerEnabled(c: Context, name: String, v: Boolean) =
        sp(c).edit().putBoolean("prayer_$name", v).apply()

    fun cacheJson(c: Context): String? = sp(c).getString("prayer_cache", null)
    fun setCacheJson(c: Context, v: String) = sp(c).edit().putString("prayer_cache", v).apply()

    fun dailyStamp(c: Context): String? = sp(c).getString("daily_stamp", null)
    fun dailyJson(c: Context): String? = sp(c).getString("daily_json", null)
    fun setDaily(c: Context, stamp: String, json: String) {
        sp(c).edit().putString("daily_stamp", stamp).putString("daily_json", json).apply()
    }

    fun dhikrCount(c: Context, id: String): Int = sp(c).getInt("dhikr_$id", 0)
    fun setDhikrCount(c: Context, id: String, v: Int) = sp(c).edit().putInt("dhikr_$id", v).apply()
}
