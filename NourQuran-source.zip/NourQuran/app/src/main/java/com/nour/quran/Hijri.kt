package com.nour.quran

import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

/** التاريخ الهجري بالتقويم الحسابي؛ قد يختلف يومًا عن رؤية الهلال، ولذلك يُعدَّل بإعداد. */
object HijriDate {
    private val MONTHS = listOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
        "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )

    fun today(offsetDays: Int): String {
        val date = HijrahDate.from(LocalDate.now().plusDays(offsetDays.toLong()))
        val day = date.get(ChronoField.DAY_OF_MONTH)
        val month = date.get(ChronoField.MONTH_OF_YEAR)
        val year = date.get(ChronoField.YEAR)
        return day.toString() + " " + MONTHS[month - 1] + " " + year + " هـ"
    }
}
