package com.nour.quran

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.io.File

class ReaderActivity : Activity() {

    private var surahNumber = 1
    private var surahName = ""
    private var focusAyah = 0
    private var ayahs: List<Ayah> = emptyList()
    private var tafsir: List<String> = emptyList()
    private var playingIndex = -1
    private var pendingAutoPlay = false
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var root: LinearLayout
    private lateinit var list: ListView
    private lateinit var status: TextView
    private lateinit var playButton: Button
    private lateinit var tafsirButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        surahNumber = intent.getIntExtra(EXTRA_SURAH, 1).coerceIn(1, 114)
        surahName = intent.getStringExtra(EXTRA_NAME) ?: SurahNames.name(surahNumber)
        focusAyah = intent.getIntExtra(EXTRA_AYAH, 0)
        buildUi()
        applyColors()
        load()
    }

    override fun onDestroy() {
        VersePlayer.stop()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = Ui.dp(this, v)

    private fun pageBg(): Int = if (Prefs.nightMode(this)) Ui.BG else Ui.PAPER
    private fun pageMuted(): Int = if (Prefs.nightMode(this)) Ui.MUTED else Ui.INK_MUTED

    private fun applyColors() {
        root.setBackgroundColor(pageBg())
        window.statusBarColor = pageBg()
        status.setTextColor(pageMuted())
        list.setBackgroundColor(pageBg())
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        status = Ui.label(this, "جاري التحميل...", 13f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(12), dp(8), dp(8))
        }
        root.addView(status)

        list = ListView(this).apply { divider = null }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(10), dp(6), dp(10), dp(10))
        }
        playButton = Ui.button(this, "تشغيل") { togglePlay() }
        tafsirButton = Ui.button(this, tafsirLabel()) { pickTafsir() }
        val menuButton = Ui.button(this, "خيارات") { openMenu() }
        bar.addView(playButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(4) })
        bar.addView(tafsirButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        bar.addView(menuButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(4) })
        root.addView(bar)

        setContentView(root)
    }

    private fun tafsirLabel(): String = "التفسير: " + TafsirSources.label(Prefs.tafsirSource(this))

    private fun pickTafsir() {
        Ui.choose(this, "التفسير", TafsirSources.list.map { it.second }) { i ->
            Prefs.setTafsirSource(this, TafsirSources.list[i].first)
            tafsirButton.text = tafsirLabel()
            stopPlayback()
            loadTafsir()
        }
    }

    // ---------- خيارات القراءة ----------

    private fun openMenu() {
        val night = Prefs.nightMode(this)
        val auto = Prefs.autoNext(this)
        val options = listOf(
            "انتقال إلى آية",
            "تكرار الآية: " + Prefs.repeatCount(this) + " مرة",
            "الوضع الليلي: " + (if (night) "مفعّل" else "معطّل"),
            "تباعد الأسطر: " + SPACING_LABELS[Prefs.lineSpacing(this).coerceIn(0, 2)],
            "متابعة السورة التالية تلقائيًا: " + (if (auto) "مفعّلة" else "معطّلة")
        )
        Ui.choose(this, "خيارات القراءة", options) { i ->
            when (i) {
                0 -> jumpToAyah()
                1 -> Ui.choose(this, "تكرار الآية", REPEAT_OPTIONS.map { it.toString() + " مرة" }) { j ->
                    Prefs.setRepeatCount(this, REPEAT_OPTIONS[j])
                }
                2 -> {
                    Prefs.setNightMode(this, !night)
                    applyColors()
                    render()
                }
                3 -> Ui.choose(this, "تباعد الأسطر", SPACING_LABELS) { j ->
                    Prefs.setLineSpacing(this, j)
                    render()
                }
                4 -> Prefs.setAutoNext(this, !auto)
                else -> Unit
            }
        }
    }

    private fun jumpToAyah() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "رقم الآية"
        }
        AlertDialog.Builder(this)
            .setTitle("انتقال إلى آية")
            .setView(input)
            .setPositiveButton("انتقال") { _, _ ->
                val n = input.text.toString().toIntOrNull()
                if (n != null && n in 1..ayahs.size) {
                    list.setSelection(n - 1)
                } else {
                    status.text = "رقم آية غير صحيح في هذه السورة."
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun toggleBookmark(position: Int) {
        val key = surahNumber.toString() + ":" + ayahs[position].number
        val marks = Prefs.bookmarks(this).toMutableSet()
        val added = marks.add(key)
        if (!added) marks.remove(key)
        Prefs.setBookmarks(this, marks)
        render()
        status.text = if (added) "أُضيفت علامة على الآية " + ayahs[position].number else "أُزيلت العلامة"
    }

    // ---------- التحميل والعرض ----------

    private fun load() {
        status.text = "جاري التحميل..."
        val edition = Prefs.edition(this)
        Net.background({ QuranRepository.surah(this@ReaderActivity, edition, surahNumber) }) { result ->
            result.onSuccess { items ->
                ayahs = items
                loadTafsir()
            }.onFailure {
                status.text = "تعذر تحميل السورة. تحقق من الإنترنت، أو حمّل القرآن من الإعدادات."
            }
        }
    }

    private fun loadTafsir() {
        val source = Prefs.tafsirSource(this)
        if (source == "none") {
            tafsir = emptyList()
            render()
            return
        }
        Net.background({ QuranRepository.tafsir(this@ReaderActivity, source, surahNumber) }) { result ->
            result.onSuccess { items ->
                tafsir = items
                render()
            }.onFailure {
                tafsir = emptyList()
                render()
                status.text = "تعذر تحميل التفسير، وتعرض الآيات فقط."
            }
        }
    }

    private fun render() {
        val withTafsir = Prefs.tafsirSource(this) != "none" && tafsir.size == ayahs.size
        val marks = Prefs.bookmarks(this)
        val rows = ayahs.mapIndexed { i, a ->
            val star = if (marks.contains(surahNumber.toString() + ":" + a.number)) "★ " else ""
            val base = star + a.text + "  ﴿" + a.number + "﴾"
            if (withTafsir) base + "\n\n" + tafsir[i] else base
        }
        list.adapter = RowAdapter(
            this, rows, Prefs.fontSize(this), Prefs.lineSpacing(this), Prefs.nightMode(this)
        ) { playingIndex }
        list.setOnItemClickListener { _, _, position, _ -> playFrom(position) }
        list.setOnItemLongClickListener { _, _, position, _ ->
            toggleBookmark(position)
            true
        }
        list.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(view: AbsListView?, scrollState: Int) {}
            override fun onScroll(view: AbsListView?, firstVisibleItem: Int, visibleItemCount: Int, totalItemCount: Int) {
                if (firstVisibleItem in ayahs.indices) {
                    Prefs.setLastRead(this@ReaderActivity, surahNumber, ayahs[firstVisibleItem].number)
                }
            }
        })

        val edition = Prefs.edition(this)
        val offline = if (OfflineStore.isTextCached(this, edition, surahNumber)) " · محفوظة بدون نت" else ""
        status.text = surahName + " · " + Editions.label(edition) + " · " +
            Reciters.label(Prefs.reciter(this)) + " · " + ayahs.size + " آية" + offline

        if (focusAyah in 1..ayahs.size) {
            list.setSelection(focusAyah - 1)
            focusAyah = 0
        }
        if (pendingAutoPlay && ayahs.isNotEmpty()) {
            pendingAutoPlay = false
            playFrom(0)
        }
    }

    private fun refreshRows() {
        (list.adapter as? BaseAdapter)?.notifyDataSetChanged()
    }

    // ---------- التلاوة ----------

    private fun togglePlay() {
        if (ayahs.isEmpty()) return
        if (playingIndex >= 0) stopPlayback() else playFrom(0)
    }

    private fun playFrom(index: Int, repeatsLeft: Int = Prefs.repeatCount(this)) {
        if (ayahs.isEmpty()) return
        if (index >= ayahs.size) {
            if (Prefs.autoNext(this) && surahNumber < 114) goNextSurah() else stopPlayback()
            return
        }
        if (index < 0) {
            stopPlayback()
            return
        }

        val edition = Prefs.edition(this)
        val reciter = Prefs.reciter(this)
        // لا نشغّل قارئًا لا ينتمي إلى الرواية المختارة، فالتلاوة يجب أن تطابق النص.
        if (Reciters.forRiwaya(edition).none { it.first == reciter }) {
            status.text = "لا يوجد قارئ مضاف لـ" + Editions.label(edition) + " بعد. اختر رواية أخرى من الإعدادات."
            stopPlayback()
            return
        }

        val ayahNumber = ayahs[index].number
        Prefs.setLastRead(this, surahNumber, ayahNumber)
        playingIndex = index
        playButton.text = "إيقاف"
        status.text = "تلاوة الآية " + ayahNumber
        list.setSelection(index)
        refreshRows()

        val file = AudioCache.file(this, reciter, surahNumber, ayahNumber)
        if (file.exists()) {
            play(file, index, repeatsLeft)
            return
        }
        val url = Reciters.url(reciter, surahNumber, ayahNumber)
        Net.background({ Net.download(url, file) }) { result ->
            result.onSuccess {
                if (playingIndex == index) play(file, index, repeatsLeft)
            }.onFailure {
                if (playingIndex == index) {
                    status.text = "تعذر تحميل الصوت. تحقق من الإنترنت."
                    stopPlayback()
                }
            }
        }
    }

    private fun play(file: File, index: Int, repeatsLeft: Int) {
        VersePlayer.playFile(
            file,
            {
                mainHandler.post {
                    if (repeatsLeft > 1) playFrom(index, repeatsLeft - 1) else playFrom(index + 1)
                }
            },
            {
                mainHandler.post {
                    status.text = "تعذر تشغيل الصوت."
                    stopPlayback()
                }
            }
        )
    }

    private fun goNextSurah() {
        VersePlayer.stop()
        playingIndex = -1
        surahNumber += 1
        surahName = SurahNames.name(surahNumber)
        focusAyah = 0
        pendingAutoPlay = true
        load()
    }

    private fun stopPlayback() {
        VersePlayer.stop()
        playingIndex = -1
        playButton.text = "تشغيل"
        refreshRows()
    }

    companion object {
        const val EXTRA_SURAH = "surah"
        const val EXTRA_NAME = "name"
        const val EXTRA_AYAH = "ayah"

        private val REPEAT_OPTIONS = listOf(1, 2, 3, 5)
        private val SPACING_LABELS = listOf("مضغوط", "عادي", "واسع")
    }
}

/** صفوف الآيات: الخط والتباعد حسب الإعداد، وتبرز الآية الجارية تلاوتها. */
private class RowAdapter(
    private val ctx: Context,
    rows: List<String>,
    fontLevel: Int,
    spacingLevel: Int,
    private val night: Boolean,
    private val playingAt: () -> Int
) : ArrayAdapter<String>(ctx, android.R.layout.simple_list_item_1, rows) {

    private val fontSize: Float = arrayOf(17f, 21f, 26f)[fontLevel.coerceIn(0, 2)]
    private val spacing: Float = arrayOf(1.2f, 1.5f, 1.9f)[spacingLevel.coerceIn(0, 2)]

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val tv = super.getView(position, convertView, parent) as TextView
        tv.setTextColor(if (night) Ui.WHITE else Ui.INK)
        tv.textSize = fontSize
        tv.gravity = Gravity.END
        tv.setLineSpacing(0f, spacing)
        val pad = Ui.dp(ctx, 12)
        tv.setPadding(pad, pad, pad, pad)
        val highlight = if (night) Ui.PANEL_LIGHT else Ui.PAPER_HIGHLIGHT
        tv.setBackgroundColor(if (position == playingAt()) highlight else Color.TRANSPARENT)
        return tv
    }
}
