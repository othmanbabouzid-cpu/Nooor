package com.nour.quran

import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.io.File

/** قارئ السورة: رأس واضح، آيات داخل بطاقات، وشريط تحكم ثابت. */
class ReaderActivity : Activity() {

    private var surahNumber = 1
    private var surahName = ""
    private var focusAyah = 0
    private var ayahs: List<Ayah> = emptyList()
    private var tafsir: List<String> = emptyList()
    private var playingIndex = -1
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var list: ListView
    private lateinit var status: TextView
    private lateinit var title: TextView
    private lateinit var meta: TextView
    private lateinit var playButton: Button
    private lateinit var tafsirButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        surahNumber = intent.getIntExtra(EXTRA_SURAH, 1)
        surahName = intent.getStringExtra(EXTRA_NAME) ?: SurahNames.name(surahNumber)
        focusAyah = intent.getIntExtra(EXTRA_AYAH, 0)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        buildUi()
        load()
    }

    override fun onDestroy() {
        VersePlayer.stop()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = Ui.dp(this, v)

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Ui.BG)
            setPadding(dp(14), dp(7), dp(14), dp(8))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(4), 0, dp(10))
        }
        val back = Ui.button(this, "‹  رجوع") { finish() }.apply {
            textSize = 12f
            setPadding(dp(9), 0, dp(9), 0)
        }
        top.addView(back, LinearLayout.LayoutParams(dp(91), dp(42)))
        top.addView(Ui.label(this, "المصحف الشريف", 13f, Ui.MUTED, true).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(Ui.pill(this, Editions.label(Prefs.edition(this)), Ui.GOLD))
        root.addView(top)

        val hero = Ui.heroCard(this)
        hero.addView(Ui.pill(this, "سورة رقم $surahNumber", Ui.GOLD))
        title = Ui.label(this, surahName, 25f, Ui.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(1))
        }
        hero.addView(title)
        meta = Ui.label(this, "${Reciters.label(Prefs.reciter(this))}  ·  ${TafsirSources.label(Prefs.tafsirSource(this))}", 10.5f, Ui.MINT).apply {
            gravity = Gravity.CENTER
        }
        hero.addView(meta)
        status = Ui.label(this, "جاري تحميل الآيات...", 11f, Ui.GOLD).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, 0)
        }
        hero.addView(status)
        root.addView(hero)

        list = ListView(this).apply {
            setBackgroundColor(Ui.BG)
            divider = null
            dividerHeight = dp(9)
            clipToPadding = false
            setPadding(0, dp(2), 0, dp(5))
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(8), 0, 0)
        }
        playButton = Ui.primaryButton(this, "تشغيل السورة") { togglePlay() }
        tafsirButton = Ui.button(this, tafsirLabel()) { pickTafsir() }
        bar.addView(playButton, LinearLayout.LayoutParams(0, dp(49), 1.1f).apply { marginEnd = dp(4) })
        bar.addView(tafsirButton, LinearLayout.LayoutParams(0, dp(49), 0.9f).apply { marginStart = dp(4) })
        root.addView(bar)
        setContentView(root)
    }

    private fun tafsirLabel(): String = "التفسير  ·  " + TafsirSources.label(Prefs.tafsirSource(this))

    private fun pickTafsir() {
        Ui.choose(this, "التفسير", TafsirSources.list.map { it.second }) { i ->
            Prefs.setTafsirSource(this, TafsirSources.list[i].first)
            tafsirButton.text = tafsirLabel()
            meta.text = "${Reciters.label(Prefs.reciter(this))}  ·  ${TafsirSources.label(Prefs.tafsirSource(this))}"
            stopPlayback()
            loadTafsir()
        }
    }

    private fun load() {
        status.text = "جاري تحميل الآيات..."
        val edition = Prefs.edition(this)
        Net.background({ QuranRepository.surah(this@ReaderActivity, edition, surahNumber) }) { result ->
            result.onSuccess { items ->
                ayahs = items
                loadTafsir()
            }.onFailure {
                status.text = "تعذر تحميل السورة. تحقق من الإنترنت أو حمّل المصحف من الإعدادات."
            }
        }
    }

    private fun loadTafsir() {
        val source = Prefs.tafsirSource(this)
        if (source == "none") {
            tafsir = emptyList()
            render()
            return
        }
        Net.background({ QuranRepository.tafsir(this@ReaderActivity, source, surahNumber) }) { result ->
            result.onSuccess { items ->
                tafsir = items
                render()
            }.onFailure {
                tafsir = emptyList()
                render()
                status.text = "تعذر تحميل التفسير، وتُعرض الآيات فقط."
            }
        }
    }

    private fun render() {
        val withTafsir = Prefs.tafsirSource(this) != "none" && tafsir.size == ayahs.size
        val rows = ayahs.mapIndexed { i, a ->
            val base = a.text + "  ﴿" + a.number + "﴾"
            if (withTafsir) base + "\n\n" + tafsir[i] else base
        }
        list.adapter = RowAdapter(this, rows, Prefs.fontSize(this)) { playingIndex }
        list.setOnItemClickListener { _, _, position, _ -> playFrom(position) }
        title.text = surahName
        status.text = "${ayahs.size} آية  ·  اضغط على آية لبدء التلاوة"
        if (focusAyah in 1..ayahs.size) {
            list.setSelection(focusAyah - 1)
            focusAyah = 0
        }
    }

    private fun togglePlay() {
        if (playingIndex >= 0) stopPlayback() else playFrom(0)
    }

    private fun playFrom(index: Int) {
        if (index < 0 || index >= ayahs.size) {
            stopPlayback()
            return
        }
        playingIndex = index
        playButton.text = "إيقاف التلاوة"
        status.text = "تلاوة الآية ${ayahs[index].number}"
        list.setSelection(index)
        refreshRows()

        val reciter = Prefs.reciter(this)
        val ayahNumber = ayahs[index].number
        val file = AudioCache.file(this, reciter, surahNumber, ayahNumber)
        if (file.exists()) play(file, index) else {
            val url = Reciters.url(reciter, surahNumber, ayahNumber)
            Net.background({ Net.download(url, file) }) { result ->
                result.onSuccess { if (playingIndex == index) play(file, index) }
                    .onFailure {
                        if (playingIndex == index) {
                            status.text = "تعذر تحميل الصوت. تحقق من الإنترنت."
                            stopPlayback()
                        }
                    }
            }
        }
    }

    private fun play(file: File, index: Int) {
        VersePlayer.playFile(
            file,
            { mainHandler.post { playFrom(index + 1) } },
            { mainHandler.post { status.text = "تعذر تشغيل الصوت."; stopPlayback() } }
        )
    }

    private fun stopPlayback() {
        VersePlayer.stop()
        playingIndex = -1
        playButton.text = "تشغيل السورة"
        refreshRows()
    }

    private fun refreshRows() { (list.adapter as? BaseAdapter)?.notifyDataSetChanged() }

    companion object {
        const val EXTRA_SURAH = "surah"
        const val EXTRA_NAME = "name"
        const val EXTRA_AYAH = "ayah"
    }
}

/** بطاقة آية بخط مريح وفصل واضح بين النص والتفسير. */
private class RowAdapter(
    private val ctx: Context,
    rows: List<String>,
    fontLevel: Int,
    private val playingAt: () -> Int
) : ArrayAdapter<String>(ctx, android.R.layout.simple_list_item_1, rows) {

    private val fontSize: Float = arrayOf(18f, 22f, 27f)[fontLevel.coerceIn(0, 2)]

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val raw = getItem(position) ?: ""
        val parts = raw.split("\n\n", limit = 2)
        val active = position == playingAt()
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(Ui.dp(ctx, 17), Ui.dp(ctx, 17), Ui.dp(ctx, 17), Ui.dp(ctx, 17))
            background = if (active) Ui.stroked(ctx, Ui.PANEL_RAISED, 20, Ui.GOLD_SOFT)
                else Ui.stroked(ctx, Ui.PANEL, 20)
        }
        val verse = Ui.label(ctx, parts[0], fontSize, Ui.WHITE).apply {
            typeface = Typeface.SERIF
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setLineSpacing(Ui.dp(ctx, 7).toFloat(), 1.25f)
            setPadding(0, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 4))
        }
        card.addView(verse)
        if (parts.size > 1 && parts[1].isNotBlank()) {
            val line = View(ctx).apply { setBackgroundColor(Ui.BORDER) }
            card.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 1)).apply {
                topMargin = Ui.dp(ctx, 10)
                bottomMargin = Ui.dp(ctx, 10)
            })
            card.addView(Ui.label(ctx, "التفسير", 10f, Ui.GOLD, true))
            card.addView(Ui.label(ctx, parts[1], 13f, Ui.MUTED).apply {
                gravity = Gravity.END
                setLineSpacing(0f, 1.35f)
                setPadding(0, Ui.dp(ctx, 5), 0, 0)
            })
        }
        return card
    }
}
