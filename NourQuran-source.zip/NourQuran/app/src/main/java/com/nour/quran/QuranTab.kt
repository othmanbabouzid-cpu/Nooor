package com.nour.quran

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/** تبويب القرآن: بحث واضح وقائمة سور مصممة كبطاقات. */
class QuranTab(private val act: Activity) {

    private var all: List<SurahInfo> = emptyList()
    private var shown: List<SurahInfo> = emptyList()
    private val searchBox = Ui.input(act, "ابحث باسم السورة أو رقمها")
    private val list = ListView(act)
    private val status = Ui.label(act, "", 12f, Ui.MUTED)
    private lateinit var settingsMeta: TextView
    private val adapter = SurahAdapter()

    val view: View = build()

    private fun build(): View {
        val page = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(Ui.dp(act, 15), Ui.dp(act, 3), Ui.dp(act, 15), 0)
        }
        val hero = Ui.heroCard(act)
        hero.addView(Ui.pill(act, "القرآن الكريم  ·  ١١٤ سورة", Ui.GOLD))
        hero.addView(Ui.label(act, "ابدأ وردك اليوم", 23f, Ui.WHITE, true).apply {
            setPadding(0, Ui.dp(act, 10), 0, Ui.dp(act, 4))
        })
        hero.addView(Ui.label(act, "اقرأ بتدبّر، واستمع إلى تلاوتك، وارجع إلى السورة التي تحبها في أي وقت.", 12f, Ui.MINT).apply {
            setLineSpacing(0f, 1.25f)
        })
        settingsMeta = Ui.label(act, "", 10.5f, Ui.GOLD, true).apply {
            setPadding(0, Ui.dp(act, 10), 0, 0)
        }
        hero.addView(settingsMeta)
        refreshMeta()
        page.addView(hero)

        page.addView(searchBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 49)).apply {
            bottomMargin = Ui.dp(act, 10)
        })
        val section = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        section.addView(Ui.sectionTitle(act, "السور"), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        section.addView(Ui.pill(act, "مرتبة حسب المصحف", Ui.MUTED))
        page.addView(section)
        status.setPadding(0, 0, 0, Ui.dp(act, 4))
        page.addView(status)
        list.apply {
            setBackgroundColor(Ui.BG)
            divider = null
            dividerHeight = Ui.dp(act, 7)
            adapter = this@QuranTab.adapter
            clipToPadding = false
            setPadding(0, 0, 0, Ui.dp(act, 10))
        }
        page.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render(s?.toString() ?: "") }
            override fun afterTextChanged(s: Editable?) {}
        })
        list.setOnItemClickListener { _, _, position, _ ->
            val s = shown[position]
            act.startActivity(Intent(act, ReaderActivity::class.java)
                .putExtra(ReaderActivity.EXTRA_SURAH, s.number)
                .putExtra(ReaderActivity.EXTRA_NAME, s.name))
        }
        load()
        return page
    }

    private fun load() {
        status.text = "يتم تجهيز فهرس السور..."
        Net.background({ QuranRepository.surahList(act) }) { result ->
            result.onSuccess { items ->
                all = items
                status.text = "١١٤ سورة متاحة للقراءة"
                render(searchBox.text.toString())
            }.onFailure {
                status.text = "تعذر تحميل قائمة السور. تحقق من اتصال الإنترنت."
            }
        }
    }

    fun refreshMeta() {
        if (::settingsMeta.isInitialized) {
            settingsMeta.text = "${Editions.label(Prefs.edition(act))}  ·  ${Reciters.label(Prefs.reciter(act))}"
        }
    }

    fun focusSearch() {
        searchBox.postDelayed({
            searchBox.requestFocus()
            val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchBox, 0)
        }, 250L)
    }

    private fun render(query: String) {
        val q = ArabicNormalizer.normalize(query)
        shown = all.filter { s ->
            q.isEmpty() || ArabicNormalizer.normalize(s.name).contains(q) ||
                s.number.toString() == q || s.english.lowercase().contains(q)
        }
        adapter.notifyDataSetChanged()
        if (q.isNotEmpty()) status.text = "${shown.size} نتيجة للبحث"
        else if (all.isNotEmpty()) status.text = "١١٤ سورة متاحة للقراءة"
    }

    private inner class SurahAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): SurahInfo = shown[position]
        override fun getItemId(position: Int): Long = shown[position].number.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val s = getItem(position)
            val row = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(Ui.dp(act, 12), Ui.dp(act, 10), Ui.dp(act, 12), Ui.dp(act, 10))
                background = Ui.stroked(act, Ui.PANEL, 17)
            }
            val number = Ui.label(act, s.number.toString(), 13f, ColorText.NUMBER, true).apply {
                gravity = Gravity.CENTER
                background = Ui.rounded(act, Ui.PANEL_RAISED, 12)
            }
            row.addView(number, LinearLayout.LayoutParams(Ui.dp(act, 40), Ui.dp(act, 40)))
            val texts = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(Ui.dp(act, 11), 0, Ui.dp(act, 8), 0)
            }
            texts.addView(Ui.label(act, s.name, 16f, Ui.WHITE, true))
            val type = if (s.revelation.equals("Meccan", true)) "مكية" else "مدنية"
            texts.addView(Ui.label(act, "${s.english}  ·  $type  ·  ${s.ayahCount} آية", 10.5f, Ui.MUTED))
            row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Ui.label(act, "‹", 25f, Ui.GOLD).apply { gravity = Gravity.CENTER })
            return row
        }
    }

    private object ColorText { val NUMBER: Int = android.graphics.Color.parseColor("#E4C77F") }
}
