package com.nour.quran

import android.app.Activity
import android.content.Intent
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView

/** تبويب القرآن: متابعة القراءة، والعلامات المرجعية، وقائمة السور مع البحث. */
class QuranTab(private val act: Activity) {

    private var all: List<SurahInfo> = emptyList()
    private val searchBox = EditText(act)
    private val list = ListView(act)
    private val status = Ui.label(act, "", 13f, Ui.MUTED)
    private val continueBox = LinearLayout(act)

    val view: View = build()

    private fun build(): View {
        val page = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(act, 12), Ui.dp(act, 8), Ui.dp(act, 12), 0)
        }
        continueBox.orientation = LinearLayout.VERTICAL
        page.addView(continueBox)
        refreshContinue()

        searchBox.apply {
            hint = "ابحث: الفاتحة، البقرة، أو الرقم"
            setHintTextColor(Ui.MUTED)
            setTextColor(Ui.WHITE)
            textSize = 15f
            setSingleLine(true)
            background = Ui.rounded(act, Ui.PANEL_LIGHT, 14)
            setPadding(Ui.dp(act, 12), Ui.dp(act, 10), Ui.dp(act, 12), Ui.dp(act, 10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    render(s?.toString() ?: "")
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        page.addView(
            searchBox,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = Ui.dp(act, 8) }
        )
        page.addView(status)
        list.apply {
            setBackgroundColor(Ui.BG)
            divider = null
        }
        page.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        load()
        return page
    }

    /** يحدّث بطاقة متابعة القراءة والعلامات، ويُستدعى عند كل ظهور للتبويب. */
    fun refreshContinue() {
        continueBox.removeAllViews()
        val last = Prefs.lastRead(act)
        if (last != null) {
            val name = SurahNames.name(last.first)
            continueBox.addView(
                Ui.button(act, "متابعة القراءة: " + name + " · الآية " + last.second) {
                    openReader(last.first, name, last.second)
                }
            )
        }
        val count = Prefs.bookmarks(act).size
        continueBox.addView(Ui.button(act, "العلامات المرجعية (" + count + ")") { showBookmarks() })
    }

    private fun showBookmarks() {
        val items = Prefs.bookmarks(act).sortedBy {
            it.substringBefore(':').toInt() * 1000 + it.substringAfter(':').toInt()
        }
        if (items.isEmpty()) {
            status.text = "لا توجد علامات مرجعية بعد. اضغط مطولًا على آية في القارئ لإضافتها."
            return
        }
        val labels = items.map { key ->
            SurahNames.name(key.substringBefore(':').toInt()) + " · الآية " + key.substringAfter(':').toInt()
        }
        Ui.choose(act, "العلامات المرجعية", labels) { i ->
            val surah = items[i].substringBefore(':').toInt()
            val ayah = items[i].substringAfter(':').toInt()
            openReader(surah, SurahNames.name(surah), ayah)
        }
    }

    private fun openReader(surah: Int, name: String, ayah: Int) {
        act.startActivity(
            Intent(act, ReaderActivity::class.java)
                .putExtra(ReaderActivity.EXTRA_SURAH, surah)
                .putExtra(ReaderActivity.EXTRA_NAME, name)
                .putExtra(ReaderActivity.EXTRA_AYAH, ayah)
        )
    }

    private fun load() {
        status.text = "جاري تحميل قائمة السور..."
        Net.background({ QuranRepository.surahList(act) }) { result ->
            result.onSuccess { items ->
                all = items
                status.text = ""
                render(searchBox.text.toString())
            }.onFailure {
                status.text = "تعذر تحميل قائمة السور. تحقق من الإنترنت."
            }
        }
    }

    private fun render(query: String) {
        val q = ArabicNormalizer.normalize(query)
        val shown = all.filter { s ->
            q.isEmpty() ||
                ArabicNormalizer.normalize(s.name).contains(q) ||
                s.number.toString() == q ||
                s.english.lowercase().contains(q)
        }
        val labels = shown.map { s -> "" + s.number + ". " + s.name + "  (" + s.ayahCount + " آية)" }
        list.adapter = ArrayAdapter(act, android.R.layout.simple_list_item_1, labels)
        list.setOnItemClickListener { _, _, position, _ ->
            val s = shown[position]
            openReader(s.number, s.name, 0)
        }
    }
}
