package com.nour.quran

import android.app.Activity
import android.app.AlarmManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** تبويب الإعدادات: القراءة، والصلاة، والتنبيهات، والتحميل بدون نت. */
class SettingsTab(private val act: Activity, private val onPrayerChanged: () -> Unit) {

    private val editionBtn: Button = Ui.button(act, "") { pickEdition() }
    private val reciterBtn: Button = Ui.button(act, "") { pickReciter() }
    private val tafsirBtn: Button = Ui.button(act, "") { pickTafsir() }
    private val fontBtn: Button = Ui.button(act, "") { pickFont() }
    private val methodBtn: Button = Ui.button(act, "") { pickMethod() }
    private val preBtn: Button = Ui.button(act, "") { pickPreMinutes() }
    private val hijriBtn: Button = Ui.button(act, "") { pickHijri() }
    private val exactBtn: Button = Ui.button(act, "السماح بالتنبيه في وقت الأذان") { openExactAlarmSettings() }
    private val downloadStatus: TextView = Ui.label(act, "", 13f, Ui.MUTED)
    private val storageStatus: TextView = Ui.label(act, "", 13f, Ui.MUTED)

    val view: View = build()

    private fun build(): View {
        val scroll = ScrollView(act)
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(act, 16), Ui.dp(act, 8), Ui.dp(act, 16), Ui.dp(act, 24))
        }
        scroll.addView(col)

        col.addView(Ui.sectionTitle(act, "القراءة"))
        col.addView(editionBtn)
        col.addView(reciterBtn)
        col.addView(tafsirBtn)
        col.addView(fontBtn)

        col.addView(Ui.sectionTitle(act, "أوقات الصلاة والتنبيهات"))
        col.addView(methodBtn)
        col.addView(preBtn)
        col.addView(hijriBtn)
        col.addView(Ui.button(act, "تحديث الموقع وأوقات الصلاة") {
            DeviceLocation.update(act)
            onPrayerChanged()
        })
        col.addView(exactBtn)
        col.addView(Ui.button(act, "إعدادات البطارية (للتنبيهات في الخلفية)") {
            act.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        col.addView(Ui.sectionTitle(act, "القرآن بدون نت"))
        col.addView(storageStatus.apply { setPadding(0, 0, 0, Ui.dp(act, 6)) })
        col.addView(Ui.button(act, "تحميل النص كاملًا للقراءة بدون نت") { startDownload() })
        col.addView(downloadStatus.apply { setPadding(0, Ui.dp(act, 6), 0, 0) })
        col.addView(Ui.button(act, "حذف الصوت المحفوظ (يبقى النص)") {
            OfflineStore.clearAudio(act)
            refreshStorage()
        })

        refresh()
        refreshStorage()
        return scroll
    }

    /** يحدّث أسماء الأزرار، ويُظهر زر التنبيه الدقيق عند الحاجة. */
    fun refresh() {
        val edition = Prefs.edition(act)
        editionBtn.text = "الرواية: " + Editions.label(edition)
        reciterBtn.text = "القارئ: " + Reciters.label(Prefs.reciter(act))
        tafsirBtn.text = "التفسير: " + TafsirSources.label(Prefs.tafsirSource(act))
        fontBtn.text = "حجم الخط: " + FONT_LABELS[Prefs.fontSize(act).coerceIn(0, 2)]
        methodBtn.text = "طريقة حساب الصلاة: " + Methods.label(Prefs.method(act))
        preBtn.text = "تنبيه قبل الصلاة: " + preLabel(Prefs.preMinutes(act))
        hijriBtn.text = "تعديل التاريخ الهجري: " + hijriLabel(Prefs.hijriOffset(act))
        exactBtn.visibility = if (needsExactAlarm()) View.VISIBLE else View.GONE
    }

    private fun refreshStorage() {
        val edition = Prefs.edition(act)
        Net.background({ OfflineStore.sizeBytes(act) }) { result ->
            result.onSuccess { bytes ->
                val mb = String.format(java.util.Locale.US, "%.1f", bytes / 1048576.0)
                storageStatus.text = "المساحة المستخدمة: " + mb + " MB · السور المحملة: " +
                    OfflineStore.textCount(act, edition) + " / 114"
            }
        }
    }

    private fun needsExactAlarm(): Boolean {
        if (Build.VERSION.SDK_INT < 31) return false
        val am = act.getSystemService(AlarmManager::class.java)
        return !am.canScheduleExactAlarms()
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= 31) {
            act.startActivity(
                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                    .setData(Uri.parse("package:" + act.packageName))
            )
        }
    }

    /** يختار القراء من الرواية المختارة فقط، ويغيّر القارئ تلقائيًا إن لم يكن تابعًا لها. */
    private fun pickEdition() {
        Ui.choose(act, "الرواية", Editions.text.map { Editions.label(it.first) }) { i ->
            val edition = Editions.text[i].first
            Prefs.setEdition(act, edition)
            val current = Prefs.reciter(act)
            if (Reciters.forRiwaya(edition).none { it.first == current }) {
                Prefs.setReciter(act, Reciters.defaultFor(edition))
            }
            refresh()
            refreshStorage()
        }
    }

    private fun pickReciter() {
        val edition = Prefs.edition(act)
        val options = Reciters.forRiwaya(edition)
        if (options.isEmpty()) {
            downloadStatus.text = "لا يوجد قارئ مضاف لـ" + Editions.label(edition) + " بعد."
            return
        }
        Ui.choose(act, "القارئ", options.map { it.second }) { i ->
            Prefs.setReciter(act, options[i].first)
            refresh()
        }
    }

    private fun pickTafsir() {
        Ui.choose(act, "التفسير", TafsirSources.list.map { it.second }) { i ->
            Prefs.setTafsirSource(act, TafsirSources.list[i].first)
            refresh()
        }
    }

    private fun pickFont() {
        Ui.choose(act, "حجم الخط", FONT_LABELS) { i ->
            Prefs.setFontSize(act, i)
            refresh()
        }
    }

    private fun pickMethod() {
        Ui.choose(act, "طريقة حساب الصلاة", Methods.list.map { it.second }) { i ->
            Prefs.setMethod(act, Methods.list[i].first)
            refresh()
            onPrayerChanged()
        }
    }

    private fun pickPreMinutes() {
        Ui.choose(act, "تنبيه قبل الصلاة", PRE_LABELS) { i ->
            Prefs.setPreMinutes(act, PRE_VALUES[i])
            refresh()
            PrayerScheduler.scheduleNext(act)
        }
    }

    private fun pickHijri() {
        Ui.choose(act, "تعديل التاريخ الهجري", HIJRI_LABELS) { i ->
            Prefs.setHijriOffset(act, HIJRI_VALUES[i])
            refresh()
        }
    }

    private fun startDownload() {
        val edition = Prefs.edition(act)
        downloadStatus.text = "جاري التحميل: 0 / 114"
        Net.background({
            QuranRepository.downloadAll(act, edition) { n ->
                act.runOnUiThread { downloadStatus.text = "جاري التحميل: $n / 114" }
            }
        }) { result ->
            result.onSuccess {
                downloadStatus.text = "تم تحميل النص. تقدر تقراه بدون نت."
                refreshStorage()
            }.onFailure { error ->
                downloadStatus.text = "توقف التحميل: " + (error.message ?: "خطأ غير معروف") + ". أعد المحاولة."
                refreshStorage()
            }
        }
    }

    private fun preLabel(minutes: Int): String = if (minutes == 0) "بدون" else "$minutes دقيقة"

    private fun hijriLabel(offset: Int): String = when (offset) {
        -1 -> "يوم أقل"
        1 -> "يوم أكثر"
        else -> "بدون تعديل"
    }

    companion object {
        private val FONT_LABELS = listOf("صغير", "متوسط", "كبير")
        private val PRE_VALUES = listOf(0, 5, 10, 15, 30)
        private val PRE_LABELS = PRE_VALUES.map { if (it == 0) "بدون تنبيه مسبق" else "$it دقيقة قبل الصلاة" }
        private val HIJRI_VALUES = listOf(-1, 0, 1)
        private val HIJRI_LABELS = listOf("يوم أقل", "بدون تعديل", "يوم أكثر")
    }
}
