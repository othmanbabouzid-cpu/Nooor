package com.nour.quran

import android.app.Activity
import android.app.AlarmManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** الإعدادات بتقسيمات واضحة وصفوف تفاعلية بدل الأزرار المتراصة. */
class SettingsTab(private val act: Activity, private val onPrayerChanged: () -> Unit) {

    private val editionValue = Ui.label(act, "", 11f, Ui.MUTED)
    private val reciterValue = Ui.label(act, "", 11f, Ui.MUTED)
    private val tafsirValue = Ui.label(act, "", 11f, Ui.MUTED)
    private val fontValue = Ui.label(act, "", 11f, Ui.MUTED)
    private val methodValue = Ui.label(act, "", 11f, Ui.MUTED)
    private lateinit var exactRow: View
    private val downloadStatus: TextView = Ui.label(act, "", 11.5f, Ui.MUTED)

    val view: View = build()

    private fun build(): View {
        val scroll = ScrollView(act)
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(Ui.dp(act, 15), Ui.dp(act, 3), Ui.dp(act, 15), Ui.dp(act, 24))
        }
        scroll.addView(col)

        val hero = Ui.heroCard(act)
        hero.addView(Ui.pill(act, "تجربة تناسبك", Ui.GOLD))
        hero.addView(Ui.label(act, "إعدادات نور القرآن", 22f, Ui.WHITE, true).apply {
            setPadding(0, Ui.dp(act, 9), 0, Ui.dp(act, 3))
        })
        hero.addView(Ui.label(act, "خصّص القراءة والتلاوة والتنبيهات بالطريقة التي تريحك.", 12f, Ui.MINT))
        col.addView(hero)

        col.addView(Ui.sectionTitle(act, "القراءة والتلاوة"))
        val reading = Ui.card(act)
        reading.addView(Ui.settingRow(act, "رواية المصحف", editionValue) { pickEdition() })
        Ui.addDivider(act, reading)
        reading.addView(Ui.settingRow(act, "القارئ", reciterValue) { pickReciter() })
        Ui.addDivider(act, reading)
        reading.addView(Ui.settingRow(act, "التفسير", tafsirValue) { pickTafsir() })
        Ui.addDivider(act, reading)
        reading.addView(Ui.settingRow(act, "حجم خط الآيات", fontValue) { pickFont() })
        col.addView(reading)

        col.addView(Ui.sectionTitle(act, "الصلاة والتنبيهات"))
        val prayer = Ui.card(act)
        prayer.addView(Ui.settingRow(act, "طريقة حساب المواقيت", methodValue) { pickMethod() })
        Ui.addDivider(act, prayer)
        prayer.addView(Ui.settingRow(act, "الموقع وأوقات الصلاة", Ui.label(act, "تحديث الموقع ثم إعادة حساب المواقيت", 11f, Ui.MUTED)) {
            DeviceLocation.update(act)
            onPrayerChanged()
        })
        Ui.addDivider(act, prayer)
        exactRow = Ui.settingRow(act, "التنبيهات الدقيقة", Ui.label(act, "السماح بوصول التنبيه في وقته المحدد", 11f, Ui.MUTED)) {
            openExactAlarmSettings()
        }
        prayer.addView(exactRow)
        Ui.addDivider(act, prayer)
        prayer.addView(Ui.settingRow(act, "تحسين عمل التنبيهات", Ui.label(act, "إعدادات البطارية في الهاتف", 11f, Ui.MUTED)) {
            act.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        col.addView(prayer)

        col.addView(Ui.sectionTitle(act, "القراءة دون اتصال"))
        val offline = Ui.card(act)
        offline.addView(Ui.label(act, "احتفظ بالمصحف على جهازك", 15f, Ui.WHITE, true))
        offline.addView(Ui.label(act, "تحميل السور يساعدك على القراءة عندما لا يتوفر الإنترنت. يحتاج التحميل إلى اتصال أولي ومساحة تخزين.", 11.5f, Ui.MUTED).apply {
            setLineSpacing(0f, 1.3f)
            setPadding(0, Ui.dp(act, 5), 0, Ui.dp(act, 11))
        })
        offline.addView(Ui.primaryButton(act, "تحميل القرآن كاملًا") { startDownload() }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 49)
        ))
        downloadStatus.setPadding(0, Ui.dp(act, 8), 0, 0)
        offline.addView(downloadStatus)
        col.addView(offline)

        col.addView(Ui.label(act, "نور القرآن  ·  الإصدار V.F", 10f, Ui.MUTED).apply {
            gravity = android.view.Gravity.CENTER
            setPadding(0, Ui.dp(act, 12), 0, 0)
        })
        refresh()
        return scroll
    }

    fun refresh() {
        editionValue.text = Editions.label(Prefs.edition(act))
        reciterValue.text = Reciters.label(Prefs.reciter(act))
        tafsirValue.text = TafsirSources.label(Prefs.tafsirSource(act))
        fontValue.text = FONT_LABELS[Prefs.fontSize(act).coerceIn(0, 2)]
        methodValue.text = Methods.label(Prefs.method(act))
        if (::exactRow.isInitialized) exactRow.visibility = if (needsExactAlarm()) View.VISIBLE else View.GONE
    }

    private fun needsExactAlarm(): Boolean {
        if (Build.VERSION.SDK_INT < 31) return false
        val am = act.getSystemService(AlarmManager::class.java)
        return !am.canScheduleExactAlarms()
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= 31) {
            act.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                .setData(Uri.parse("package:" + act.packageName)))
        }
    }

    private fun pickEdition() {
        Ui.choose(act, "رواية المصحف", Editions.text.map { Editions.label(it.first) }) { i ->
            Prefs.setEdition(act, Editions.text[i].first)
            refresh()
        }
    }

    private fun pickReciter() {
        Ui.choose(act, "اختر القارئ", Reciters.list.map { it.second }) { i ->
            Prefs.setReciter(act, Reciters.list[i].first)
            refresh()
        }
    }

    private fun pickTafsir() {
        Ui.choose(act, "اختر التفسير", TafsirSources.list.map { it.second }) { i ->
            Prefs.setTafsirSource(act, TafsirSources.list[i].first)
            refresh()
        }
    }

    private fun pickFont() {
        Ui.choose(act, "حجم الخط", FONT_LABELS) { i ->
            Prefs.setFontSize(act, i)
            refresh()
        }
    }

    private fun pickMethod() {
        Ui.choose(act, "طريقة حساب الصلاة", Methods.list.map { it.second }) { i ->
            Prefs.setMethod(act, Methods.list[i].first)
            refresh()
            onPrayerChanged()
        }
    }

    private fun startDownload() {
        val edition = Prefs.edition(act)
        downloadStatus.text = "جاري التحميل: 0 / 114"
        Net.background({
            QuranRepository.downloadAll(act, edition) { n ->
                act.runOnUiThread { downloadStatus.text = "جاري التحميل: $n / 114" }
            }
        }) { result ->
            result.onSuccess { downloadStatus.text = "اكتمل التحميل. يمكنك القراءة دون إنترنت." }
                .onFailure { error -> downloadStatus.text = "توقف التحميل: ${error.message ?: "خطأ غير معروف"}. أعد المحاولة." }
        }
    }

    companion object { private val FONT_LABELS = listOf("صغير", "متوسط", "كبير") }
}
