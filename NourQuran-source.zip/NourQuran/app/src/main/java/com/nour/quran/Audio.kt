package com.nour.quran

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import java.io.File

/** مشغّل آية واحدة في كل مرة، يشغّل من ملف محلي. */
object VersePlayer {
    private var player: MediaPlayer? = null

    fun playFile(file: File, onDone: () -> Unit, onError: () -> Unit) {
        stop()
        val mp = MediaPlayer()
        player = mp
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            mp.setDataSource(file.absolutePath)
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener { onDone() }
            mp.setOnErrorListener { _, _, _ ->
                onError()
                true
            }
            mp.prepareAsync()
        } catch (_: Exception) {
            stop()
            onError()
        }
    }

    fun stop() {
        val mp = player ?: return
        player = null
        try {
            mp.stop()
        } catch (_: Exception) {
        }
        mp.release()
    }
}

/** ملفات الصوت التي تُشغَّل تُحفظ محليًا، فتُعاد تلاوتها بدون نت. */
object AudioCache {
    fun file(c: Context, folder: String, surah: Int, ayah: Int): File =
        File(c.filesDir, "audio/" + folder + "/" + String.format("%03d%03d.mp3", surah, ayah))
}
