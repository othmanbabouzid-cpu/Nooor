package com.nour.quran

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PrayerScheduler {
    private const val MAIN_PREFIX = "com.nour.quran.PRAYER_"
    private const val PRE_PREFIX = "com.nour.quran.PRE_"
    private const val DAY = 86400000L
    private const val MINUTE = 60000L

    /** قنوات الإشعار: صوت، اهتزاز، صامت. الترتيب يطابق أوضاع Prefs.prayerMode. */
    private val CHANNELS = listOf("prayer_sound", "prayer_vibrate", "prayer_silent")

    fun todayIso(): String = isoDate(System.currentTimeMillis())

    private fun isoDate(millis: Long): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(millis))

    fun ensureChannels(c: Context) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNELS[0], "أوقات الصلاة (صوت)", NotificationManager.IMPORTANCE_HIGH)
        )
        val vibrate = NotificationChannel(CHANNELS[1], "أوقات الصلاة (اهتزاز)", NotificationManager.IMPORTANCE_DEFAULT)
        vibrate.setSound(null, null)
        vibrate.enableVibration(true)
        nm.createNotificationChannel(vibrate)
        val silent = NotificationChannel(CHANNELS[2], "أوقات الصلاة (صامت)", NotificationManager.IMPORTANCE_LOW)
        silent.setSound(null, null)
        silent.enableVibration(false)
        nm.createNotificationChannel(silent)
    }

    /** يجدول تنبيه كل صلاة مفعّلة، وتنبيهها المسبق إن كان مفعّلًا. */
    fun scheduleNext(c: Context) {
        ensureChannels(c)
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val days = PrayerCache.load(c).days
        val now = System.currentTimeMillis()
        val preMs = Prefs.preMinutes(c) * MINUTE
        for (name in PrayerNames.ALL) {
            cancel(am, c, MAIN_PREFIX + name)
            cancel(am, c, PRE_PREFIX + name)
            if (!Prefs.prayerEnabled(c, name)) continue
            val at = PrayerCache.nextTime(days, name, now) ?: continue
            set(am, c, MAIN_PREFIX + name, at)
            if (preMs > 0 && at - preMs > now + 1000L) {
                set(am, c, PRE_PREFIX + name, at - preMs)
            }
        }
    }

    private fun piFor(c: Context, action: String): PendingIntent {
        val intent = Intent(c, PrayerReceiver::class.java).setAction(action)
        return PendingIntent.getBroadcast(
            c,
            action.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun cancel(am: AlarmManager, c: Context, action: String) {
        am.cancel(piFor(c, action))
    }

    private fun set(am: AlarmManager, c: Context, action: String, at: Long) {
        val pi = piFor(c, action)
        if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } else {
            // بدون إذن التنبيهات الدقيقة قد يتأخر التنبيه بضع دقائق.
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    /** يرجع اسم الصلاة، وهل هو تنبيه مسبق، أو null إن لم يكن الإجراء من هذا التطبيق. */
    fun parseAction(action: String?): Pair<String, Boolean>? {
        if (action == null) return null
        return when {
            action.startsWith(PRE_PREFIX) -> Pair(action.removePrefix(PRE_PREFIX), true)
            action.startsWith(MAIN_PREFIX) -> Pair(action.removePrefix(MAIN_PREFIX), false)
            else -> null
        }
    }

    /** preMinutes = null يعني التنبيه الأصلي عند وقت الصلاة. */
    fun showNotification(c: Context, name: String, preMinutes: Int?) {
        ensureChannels(c)
        val channel = CHANNELS[Prefs.prayerMode(c, name).coerceIn(0, 2)]
        val title = if (preMinutes == null) {
            "حان وقت صلاة " + PrayerNames.arabic(name)
        } else {
            "بعد " + preMinutes + " دقيقة صلاة " + PrayerNames.arabic(name)
        }
        val text = if (preMinutes == null) "حيّ على الصلاة" else "استعد للصلاة"
        val notification = Notification.Builder(c, channel)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .build()
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val id = name.hashCode() + (if (preMinutes == null) 0 else 1)
        nm.notify(id, notification)
    }

    /** يحدّث الكاش إذا لزم الأمر، ثم يعيد جدولة التنبيهات. */
    fun refresh(c: Context, force: Boolean, done: (Result<String>) -> Unit) {
        val key = PrayerCache.key(c)
        val cache = PrayerCache.load(c)
        val lastDate = cache.days.maxOfOrNull { it.date } ?: ""
        val needFetch = force || cache.key != key || lastDate < isoDate(System.currentTimeMillis() + 3L * DAY)

        if (!needFetch) {
            scheduleNext(c)
            done(Result.success("أوقات الصلاة محدّثة."))
            return
        }

        val lat = Prefs.lat(c)
        val lng = Prefs.lng(c)
        val method = Prefs.method(c)
        Net.background({
            val cal = java.util.Calendar.getInstance()
            val firstYear = cal.get(java.util.Calendar.YEAR)
            val firstMonth = cal.get(java.util.Calendar.MONTH) + 1
            val first = PrayerApi.fetchMonth(lat, lng, method, firstYear, firstMonth)
            cal.add(java.util.Calendar.MONTH, 1)
            val second = PrayerApi.fetchMonth(
                lat, lng, method, cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH) + 1
            )
            first + second
        }) { result ->
            result.onSuccess { days ->
                PrayerCache.save(c, key, days)
                scheduleNext(c)
                done(Result.success("تم تحديث أوقات الصلاة."))
            }.onFailure { error ->
                done(Result.failure(error))
            }
        }
    }
}
