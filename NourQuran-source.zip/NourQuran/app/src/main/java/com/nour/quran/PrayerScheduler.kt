package com.nour.quran

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object PrayerScheduler {
    private const val ACTION_PREFIX = "com.nour.quran.PRAYER_"
    private const val CHANNEL = "prayer_times"
    private const val DAY = 86400000L

    fun todayIso(): String = isoDate(System.currentTimeMillis())

    private fun isoDate(millis: Long): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(millis))

    /** يجدول تنبيه كل صلاة مفعّلة عند أقرب وقت قادم. */
    fun scheduleNext(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val days = PrayerCache.load(c).days
        val now = System.currentTimeMillis()
        for (name in PrayerNames.ALL) {
            val pi = pendingFor(c, name)
            am.cancel(pi)
            if (!Prefs.prayerEnabled(c, name)) continue
            val at = PrayerCache.nextTime(days, name, now) ?: continue
            if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                // بدون إذن التنبيهات الدقيقة قد يتأخر التنبيه بضع دقائق.
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        }
        ClockWidgetProvider.updateAll(c)
    }

    private fun pendingFor(c: Context, name: String): PendingIntent {
        val intent = Intent(c, PrayerReceiver::class.java).setAction(ACTION_PREFIX + name)
        return PendingIntent.getBroadcast(
            c,
            name.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun actionToPrayer(action: String?): String? =
        action?.takeIf { it.startsWith(ACTION_PREFIX) }?.removePrefix(ACTION_PREFIX)

    fun showNotification(c: Context, name: String) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "أوقات الصلاة", NotificationManager.IMPORTANCE_HIGH)
        )
        val notification = Notification.Builder(c, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("حان وقت صلاة " + PrayerNames.arabic(name))
            .setContentText("حيّ على الصلاة")
            .setAutoCancel(true)
            .build()
        nm.notify(name.hashCode(), notification)
    }

    /**
     * يحدّث الكاش إذا لزم الأمر (تغيّر الموقع أو الطريقة، أو اقتراب نفاد الأيام المحفوظة)،
     * ثم يعيد جدولة التنبيهات.
     */
    fun refresh(c: Context, force: Boolean, done: (Result<String>) -> Unit) {
        val key = PrayerCache.key(c)
        val cache = PrayerCache.load(c)
        val lastDate = cache.days.maxOfOrNull { it.date } ?: ""
        val needFetch = force || cache.key != key || lastDate < isoDate(System.currentTimeMillis() + 3L * DAY)

        if (!needFetch) {
            scheduleNext(c)
            done(Result.success("أوقات الصلاة محدّثة."))
            return
        }

        val lat = Prefs.lat(c)
        val lng = Prefs.lng(c)
        val method = Prefs.method(c)
        Net.background({
            val cal = Calendar.getInstance()
            val firstYear = cal.get(Calendar.YEAR)
            val firstMonth = cal.get(Calendar.MONTH) + 1
            val first = PrayerApi.fetchMonth(lat, lng, method, firstYear, firstMonth)
            cal.add(Calendar.MONTH, 1)
            val second = PrayerApi.fetchMonth(lat, lng, method, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1)
            first + second
        }) { result ->
            result.onSuccess { days ->
                PrayerCache.save(c, key, days)
                scheduleNext(c)
                done(Result.success("تم تحديث أوقات الصلاة."))
            }.onFailure { error ->
                done(Result.failure(error))
            }
        }
    }
}
