package com.nour.quran

import android.app.Activity
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView

/** تبويب الصلاة: الصلاة القادمة مع العد التنازلي، وأوقات اليوم، وإعداد كل تنبيه. */
class PrayerTab(private val act: Activity) {

    private val hijriText = Ui.label(act, "", 14f, Ui.MUTED)
    private val nextText = Ui.label(act, "", 18f, Ui.CYAN, true)
    private val countdownText = Ui.label(act, "", 14f, Ui.WHITE)
    private val statusText = Ui.label(act, "", 13f, Ui.MUTED)
    private val table = LinearLayout(act)

    val view: View = build()

    private fun build(): View {
        val scroll = ScrollView(act)
        val page = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(act, 16), Ui.dp(act, 10), Ui.dp(act, 16), Ui.dp(act, 16))
        }
        scroll.addView(page)
        hijriText.gravity = Gravity.CENTER
        nextText.gravity = Gravity.CENTER
        countdownText.gravity = Gravity.CENTER
        statusText.gravity = Gravity.CENTER
        statusText.setPadding(0, Ui.dp(act, 6), 0, Ui.dp(act, 10))
        page.addView(hijriText)
        page.addView(nextText)
        page.addView(countdownText)
        page.addView(statusText)
        table.orientation = LinearLayout.VERTICAL
        page.addView(table)
        page.addView(Ui.button(act, "تحديث أوقات الصلاة") { refresh(true) })
        return scroll
    }

    fun refresh(force: Boolean) {
        statusText.text = "جاري تحديث أوقات الصلاة..."
        PrayerScheduler.refresh(act, force) { result ->
            result.onSuccess { message ->
                statusText.text = message
            }.onFailure {
                statusText.text = "تعذر تحديث الأوقات. تحقق من الإنترنت ثم أعد المحاولة."
            }
            showPrayers()
        }
    }

    fun showPrayers() {
        hijriText.text = HijriDate.today(Prefs.hijriOffset(act))
        val cache = PrayerCache.load(act)
        val today = PrayerScheduler.todayIso()
        val day = cache.days.firstOrNull { it.date == today }
        table.removeAllViews()
        for (name in PrayerNames.ALL) {
            val row = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(Ui.dp(act, 4), Ui.dp(act, 8), Ui.dp(act, 4), Ui.dp(act, 8))
            }
            val time = if (day != null) day.times[name] ?: "--:--" else "--:--"
            row.addView(
                Ui.label(act, PrayerNames.arabic(name), 16f, Ui.WHITE, true),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(
                Ui.label(act, time, 16f, Ui.CYAN),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )

            val modeButton: Button = Ui.button(act, MODE_LABELS[Prefs.prayerMode(act, name).coerceIn(0, 2)]) {
                Prefs.setPrayerMode(act, name, (Prefs.prayerMode(act, name) + 1) % 3)
                showPrayers()
            }
            row.addView(modeButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(act, 40)).apply {
                marginEnd = Ui.dp(act, 6)
            })

            val checkBox = CheckBox(act).apply {
                text = "تنبيه"
                setTextColor(Ui.WHITE)
                isChecked = Prefs.prayerEnabled(act, name)
            }
            checkBox.setOnCheckedChangeListener { _, checked ->
                Prefs.setPrayerEnabled(act, name, checked)
                PrayerScheduler.scheduleNext(act)
            }
            row.addView(checkBox)
            table.addView(row)
        }

        val now = System.currentTimeMillis()
        val next = PrayerCache.nextPrayer(cache.days, now)
        if (next == null) {
            nextText.text = "لا توجد أوقات محفوظة بعد"
            countdownText.text = ""
        } else {
            nextText.text = "الصلاة القادمة: " + PrayerNames.arabic(next.first) + " · " + PrayerCache.clock(next.second)
            val minutes = (next.second - now) / 60000L
            val h = minutes / 60
            val m = minutes % 60
            countdownText.text = "متبقي " + (if (h > 0) h.toString() + " ساعة و " else "") + m + " دقيقة"
        }
    }

    companion object {
        private val MODE_LABELS = listOf("صوت", "اهتزاز", "صامت")
    }
}
