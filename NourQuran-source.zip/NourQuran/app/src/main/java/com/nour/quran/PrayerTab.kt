package com.nour.quran

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView

/** تبويب الصلاة: إبراز الصلاة القادمة وجدول يومي سهل القراءة. */
class PrayerTab(private val act: Activity) {

    private val nextName = Ui.label(act, "الصلاة القادمة", 12f, Ui.MINT, true)
    private val nextText = Ui.label(act, "يتم حساب المواقيت", 25f, Ui.WHITE, true)
    private val nextTime = Ui.label(act, "--:--", 18f, Ui.GOLD, true)
    private val statusText = Ui.label(act, "", 11.5f, Ui.MUTED)
    private val table = LinearLayout(act)

    val view: View = build()

    private fun build(): View {
        val scroll = ScrollView(act)
        val page = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(Ui.dp(act, 15), Ui.dp(act, 3), Ui.dp(act, 15), Ui.dp(act, 20))
        }
        scroll.addView(page)
        val hero = Ui.heroCard(act)
        hero.addView(Ui.pill(act, "مواقيت اليوم", Ui.GOLD))
        nextName.setPadding(0, Ui.dp(act, 12), 0, Ui.dp(act, 2))
        hero.addView(nextName)
        hero.addView(nextText)
        hero.addView(nextTime.apply { setPadding(0, Ui.dp(act, 3), 0, 0) })
        page.addView(hero)

        val head = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        head.addView(Ui.sectionTitle(act, "جدول الصلوات"), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(Ui.pill(act, "تنبيه لكل صلاة", Ui.MUTED))
        page.addView(head)
        table.orientation = LinearLayout.VERTICAL
        table.layoutDirection = View.LAYOUT_DIRECTION_RTL
        page.addView(table)
        page.addView(Ui.primaryButton(act, "تحديث أوقات الصلاة") { refresh(true) }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 50)
        ).apply { topMargin = Ui.dp(act, 5) })
        statusText.gravity = Gravity.CENTER
        statusText.setPadding(0, Ui.dp(act, 9), 0, 0)
        page.addView(statusText)
        return scroll
    }

    fun refresh(force: Boolean) {
        statusText.text = "يتم تحديث مواقيت الصلاة..."
        PrayerScheduler.refresh(act, force) { result ->
            result.onSuccess { message -> statusText.text = message }
                .onFailure { statusText.text = "تعذر تحديث الأوقات. تحقق من الإنترنت ثم أعد المحاولة." }
            showPrayers()
        }
    }

    fun showPrayers() {
        val cache = PrayerCache.load(act)
        val today = PrayerScheduler.todayIso()
        val day = cache.days.firstOrNull { it.date == today }
        table.removeAllViews()
        for ((index, name) in PrayerNames.ALL.withIndex()) {
            val row = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(Ui.dp(act, 13), Ui.dp(act, 11), Ui.dp(act, 13), Ui.dp(act, 11))
                background = Ui.stroked(act, Ui.PANEL, 17)
            }
            val number = Ui.label(act, (index + 1).toString().padStart(2, '0'), 10f, Ui.GOLD, true).apply {
                gravity = Gravity.CENTER
                background = Ui.rounded(act, Ui.PANEL_RAISED, 10)
            }
            row.addView(number, LinearLayout.LayoutParams(Ui.dp(act, 31), Ui.dp(act, 31)))
            val title = Ui.label(act, PrayerNames.arabic(name), 15f, Ui.WHITE, true).apply {
                setPadding(Ui.dp(act, 10), 0, Ui.dp(act, 7), 0)
            }
            row.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val time = if (day != null) day.times[name] ?: "--:--" else "--:--"
            row.addView(Ui.label(act, time, 17f, Ui.GOLD, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, 0, Ui.dp(act, 8), 0)
            })
            val checkBox = CheckBox(act).apply {
                text = "تنبيه"
                textSize = 10f
                setTextColor(Ui.MUTED)
                buttonTintList = ColorStateList.valueOf(Ui.GOLD)
                isChecked = Prefs.prayerEnabled(act, name)
            }
            checkBox.setOnCheckedChangeListener { _, checked ->
                Prefs.setPrayerEnabled(act, name, checked)
                PrayerScheduler.scheduleNext(act)
            }
            row.addView(checkBox)
            table.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = Ui.dp(act, 8) })
        }

        val next = PrayerCache.nextPrayer(cache.days, System.currentTimeMillis())
        if (next == null) {
            nextName.text = "الصلاة القادمة"
            nextText.text = "لم تُحفظ المواقيت بعد"
            nextTime.text = "--:--"
        } else {
            nextName.text = "الصلاة القادمة"
            nextText.text = PrayerNames.arabic(next.first)
            nextTime.text = PrayerCache.clock(next.second)
        }
    }
}
