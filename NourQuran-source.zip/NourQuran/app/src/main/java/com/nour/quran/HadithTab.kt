package com.nour.quran

import android.app.Activity
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView

/** تبويب الحديث: اختيار المصدر والبحث وعرض المتون بتنسيق مقروء. */
class HadithTab(private val act: Activity) {

    private var items: List<Hadith> = emptyList()
    private var matches: List<Hadith> = emptyList()
    private var loadedKey = ""
    private val searchBox: EditText = Ui.input(act, "ابحث في نص الحديث")
    private val list = ListView(act)
    private val status = Ui.label(act, "", 11.5f, Ui.MUTED)
    private val pickButton: Button = Ui.button(act, "") { pickCollection() }
    private val adapter = HadithAdapter()

    val view: View = build()

    private fun build(): View {
        val page = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(Ui.dp(act, 15), Ui.dp(act, 3), Ui.dp(act, 15), 0)
        }
        val hero = Ui.heroCard(act)
        hero.addView(Ui.pill(act, "من كتب السنة", Ui.GOLD))
        hero.addView(Ui.label(act, "مكتبة الحديث", 22f, Ui.WHITE, true).apply {
            setPadding(0, Ui.dp(act, 9), 0, Ui.dp(act, 3))
        })
        hero.addView(Ui.label(act, "ابحث في المرويات واختر المجموعة التي تريد القراءة منها.", 12f, Ui.MINT))
        page.addView(hero)
        pickButton.textSize = 13f
        page.addView(pickButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 46)).apply {
            bottomMargin = Ui.dp(act, 8)
        })
        page.addView(searchBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 49)).apply {
            bottomMargin = Ui.dp(act, 8)
        })
        status.setPadding(0, 0, 0, Ui.dp(act, 5))
        page.addView(status)
        list.apply {
            setBackgroundColor(Ui.BG)
            divider = null
            dividerHeight = Ui.dp(act, 8)
            adapter = this@HadithTab.adapter
            clipToPadding = false
            setPadding(0, 0, 0, Ui.dp(act, 10))
        }
        page.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render(s?.toString() ?: "") }
            override fun afterTextChanged(s: Editable?) {}
        })
        refreshLabel()
        return page
    }

    fun onShown() { load() }

    private fun refreshLabel() { pickButton.text = "المجموعة الحالية  ·  ${HadithCollections.label(Prefs.hadithCollection(act))}  ▾" }

    private fun pickCollection() {
        Ui.choose(act, "اختر مجموعة الحديث", HadithCollections.list.map { it.second }) { i ->
            Prefs.setHadithCollection(act, HadithCollections.list[i].first)
            refreshLabel()
            load()
        }
    }

    private fun load() {
        val key = Prefs.hadithCollection(act)
        if (key == loadedKey && items.isNotEmpty()) {
            render(searchBox.text.toString())
            return
        }
        status.text = "يتم تحميل مكتبة الحديث..."
        Net.background({ HadithRepository.load(act, key) }) { result ->
            result.onSuccess { loaded ->
                items = loaded
                loadedKey = key
                render(searchBox.text.toString())
            }.onFailure {
                status.text = "تعذر تحميل الأحاديث. تحقق من الاتصال أو مصدر الملفات."
            }
        }
    }

    private fun render(query: String) {
        val q = ArabicNormalizer.normalize(query)
        val found = ArrayList<Hadith>()
        for (h in items) {
            if (q.isEmpty() || ArabicNormalizer.normalize(h.text).contains(q)) {
                found.add(h)
                if (found.size >= 200) break
            }
        }
        matches = found
        adapter.notifyDataSetChanged()
        if (items.isNotEmpty()) status.text = "${matches.size} حديث معروض من ${items.size}"
    }

    private inner class HadithAdapter : BaseAdapter() {
        override fun getCount(): Int = matches.size
        override fun getItem(position: Int): Hadith = matches[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val hadith = getItem(position)
            val card = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(Ui.dp(act, 15), Ui.dp(act, 13), Ui.dp(act, 15), Ui.dp(act, 14))
                background = Ui.stroked(act, Ui.PANEL, 18)
            }
            card.addView(Ui.pill(act, "حديث رقم ${hadith.number}", Ui.GOLD))
            card.addView(Ui.label(act, hadith.text, 15f, Ui.WHITE).apply {
                gravity = Gravity.END
                setLineSpacing(0f, 1.45f)
                setPadding(0, Ui.dp(act, 10), 0, 0)
            })
            return card
        }
    }
}
