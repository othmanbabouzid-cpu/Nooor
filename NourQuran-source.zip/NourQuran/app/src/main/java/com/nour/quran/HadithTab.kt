package com.nour.quran

import android.app.Activity
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView

/** تبويب الحديث: اختيار المجموعة، والبحث داخلها. */
class HadithTab(private val act: Activity) {

    private var items: List<Hadith> = emptyList()
    private var loadedKey = ""
    private val searchBox = EditText(act)
    private val list = ListView(act)
    private val status = Ui.label(act, "", 13f, Ui.MUTED)
    private val pickButton: Button = Ui.button(act, "") { pickCollection() }

    val view: View = build()

    private fun build(): View {
        val page = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(act, 12), Ui.dp(act, 8), Ui.dp(act, 12), 0)
        }
        page.addView(pickButton)
        searchBox.apply {
            hint = "ابحث في الحديث"
            setHintTextColor(Ui.MUTED)
            setTextColor(Ui.WHITE)
            textSize = 15f
            setSingleLine(true)
            background = Ui.rounded(act, Ui.PANEL_LIGHT, 14)
            setPadding(Ui.dp(act, 12), Ui.dp(act, 10), Ui.dp(act, 12), Ui.dp(act, 10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    render(s?.toString() ?: "")
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        page.addView(
            searchBox,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = Ui.dp(act, 6); bottomMargin = Ui.dp(act, 6) }
        )
        page.addView(status)
        list.apply {
            setBackgroundColor(Ui.BG)
            divider = null
        }
        page.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        refreshLabel()
        return page
    }

    /** يُستدعى عند فتح التبويب، فلا يُحمَّل ملف الحديث الكبير إلا عند الحاجة. */
    fun onShown() {
        load()
    }

    private fun refreshLabel() {
        pickButton.text = "المجموعة: " + HadithCollections.label(Prefs.hadithCollection(act))
    }

    private fun pickCollection() {
        Ui.choose(act, "مجموعة الحديث", HadithCollections.list.map { it.second }) { i ->
            Prefs.setHadithCollection(act, HadithCollections.list[i].first)
            refreshLabel()
            load()
        }
    }

    private fun load() {
        val key = Prefs.hadithCollection(act)
        if (key == loadedKey && items.isNotEmpty()) {
            render(searchBox.text.toString())
            return
        }
        status.text = "جاري تحميل الحديث..."
        Net.background({ HadithRepository.load(act, key) }) { result ->
            result.onSuccess { loaded ->
                items = loaded
                loadedKey = key
                status.text = "عدد الأحاديث: " + loaded.size
                render(searchBox.text.toString())
            }.onFailure {
                status.text = "تعذر تحميل الحديث. تحقق من الإنترنت، وتأكد من اسم الملف في الإعدادات."
            }
        }
    }

    /** يعرض أول 200 نتيجة فقط، حتى تبقى القائمة سريعة. */
    private fun render(query: String) {
        val q = ArabicNormalizer.normalize(query)
        val matches = ArrayList<Hadith>()
        for (h in items) {
            if (q.isEmpty() || ArabicNormalizer.normalize(h.text).contains(q)) {
                matches.add(h)
                if (matches.size >= 200) break
            }
        }
        val labels = matches.map { h -> h.number + ". " + h.text }
        list.adapter = ArrayAdapter(act, android.R.layout.simple_list_item_1, labels)
    }
}
