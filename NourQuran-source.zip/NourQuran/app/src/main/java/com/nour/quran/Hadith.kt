package com.nour.quran

import android.content.Context
import org.json.JSONObject
import java.io.File

data class Hadith(val number: String, val text: String)

object HadithCollections {
    /** المفاتيح تطابق أسماء الملفات في مستودع الحديث. تحقّق من أسماء الملفات قبل النشر. */
    val list: List<Pair<String, String>> = listOf(
        "malik" to "موطأ الإمام مالك",
        "bukhari" to "صحيح البخاري",
        "muslim" to "صحيح مسلم"
    )

    fun label(key: String): String = list.firstOrNull { it.first == key }?.second ?: key
}

object HadithRepository {

    /** يجب استدعاؤها من خيط خلفي. */
    fun load(c: Context, key: String): List<Hadith> {
        val file = File(c.filesDir, "hadith/$key.json")
        if (!file.exists()) Net.download(Endpoints.HADITH_CDN + "/ara-$key.json", file)
        val arr = JSONObject(file.readText()).getJSONArray("hadiths")
        val out = ArrayList<Hadith>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val text = o.optString("text", "").trim()
            if (text.isNotEmpty()) {
                out.add(Hadith(o.opt("hadithnumber")?.toString() ?: "", text))
            }
        }
        return out
    }
}
