package com.nour.quran

import android.os.Handler
import android.os.Looper
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** عناوين الخدمات. تحقّق منها قبل النشر، فهي لم تُختبر من بيئة البناء. */
object Endpoints {
    const val ALQURAN = "https://api.alquran.cloud/v1"
    const val ALADHAN = "https://api.aladhan.com/v1"
    const val EVERYAYAH = "https://everyayah.com/data"
    const val TAFSIR_CDN = "https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@v1.2.3/tafsir"
    const val HADITH_CDN = "https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions"
}

object Net {
    private val main = Handler(Looper.getMainLooper())

    private fun open(url: String): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.requestMethod = "GET"
        return conn
    }

    /** يجب استدعاؤها من خيط خلفي فقط. */
    fun get(url: String): String {
        val conn = open(url)
        return try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    /** يحمّل ملفًا. يكتب في ملف مؤقت أولًا حتى لا يبقى ملف ناقص عند انقطاع النت. */
    fun download(url: String, target: File) {
        val conn = open(url)
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            val dir = target.parentFile
            if (dir != null) dir.mkdirs()
            val tmp = File(dir, target.name + ".part")
            conn.inputStream.use { input -> tmp.outputStream().use { out -> input.copyTo(out) } }
            if (!tmp.renameTo(target)) throw IllegalStateException("تعذر حفظ الملف")
        } finally {
            conn.disconnect()
        }
    }

    /** ينفذ العمل في خيط خلفي، ثم يسلّم النتيجة للخيط الرئيسي. */
    fun <T> background(work: () -> T, done: (Result<T>) -> Unit) {
        Thread {
            val result = runCatching(work)
            main.post { done(result) }
        }.start()
    }
}
