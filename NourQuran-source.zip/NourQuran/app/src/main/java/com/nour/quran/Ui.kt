package com.nour.quran

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** عناصر واجهة مشتركة بثيم داكن، وألوان ورق القراءة الليلي والنهاري. */
object Ui {
    val BG: Int = Color.parseColor("#080A12")
    val PANEL: Int = Color.parseColor("#111629")
    val PANEL_LIGHT: Int = Color.parseColor("#1B2340")
    val PURPLE: Int = Color.parseColor("#7957E8")
    val CYAN: Int = Color.parseColor("#55D7F2")
    val WHITE: Int = Color.parseColor("#F2F4FC")
    val MUTED: Int = Color.parseColor("#9AA4BC")

    val PAPER: Int = Color.parseColor("#F4ECD8")
    val PAPER_HIGHLIGHT: Int = Color.parseColor("#E6DCC2")
    val INK: Int = Color.parseColor("#1E1B16")
    val INK_MUTED: Int = Color.parseColor("#6B6254")

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun rounded(c: Context, color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(c, radiusDp).toFloat()
        }

    fun label(c: Context, text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(c).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun button(c: Context, text: String, onClick: () -> Unit): Button =
        Button(c).apply {
            this.text = text
            isAllCaps = false
            textSize = 14f
            setTextColor(WHITE)
            background = rounded(c, PANEL_LIGHT, 12)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 48))
                .apply { topMargin = dp(c, 6) }
            setOnClickListener { onClick() }
        }

    fun card(c: Context): LinearLayout =
        LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12))
            background = rounded(c, PANEL, 18)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = dp(c, 10) }
        }

    fun sectionTitle(c: Context, text: String): TextView =
        label(c, text, 16f, CYAN, true).apply { setPadding(0, dp(c, 14), 0, dp(c, 4)) }

    fun choose(c: Context, title: String, options: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(c)
            .setTitle(title)
            .setItems(options.toTypedArray()) { _, which -> onPick(which) }
            .show()
    }
}
