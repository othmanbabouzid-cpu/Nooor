package com.nour.quran

import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** نظام التصميم الموحد لتطبيق نور القرآن. */
object Ui {
    val BG: Int = Color.parseColor("#081510")
    val PANEL: Int = Color.parseColor("#11231C")
    val PANEL_LIGHT: Int = Color.parseColor("#1A3026")
    val PANEL_RAISED: Int = Color.parseColor("#20392E")
    val GOLD: Int = Color.parseColor("#D9B96E")
    val GOLD_SOFT: Int = Color.parseColor("#B99A58")
    val MINT: Int = Color.parseColor("#B6D0BE")
    val WHITE: Int = Color.parseColor("#F4F1E8")
    val MUTED: Int = Color.parseColor("#9BAC9F")
    val BORDER: Int = Color.parseColor("#294237")

    // توافق مع بقية ملفات المشروع القديمة.
    val PURPLE: Int = GOLD
    val CYAN: Int = MINT

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun rounded(c: Context, color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(c, radiusDp).toFloat()
        }

    fun stroked(c: Context, color: Int, radiusDp: Int, strokeColor: Int = BORDER): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(c, radiusDp).toFloat()
            setStroke(dp(c, 1), strokeColor)
        }

    fun gradient(c: Context, colors: IntArray, radiusDp: Int = 24): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
            cornerRadius = dp(c, radiusDp).toFloat()
        }

    fun label(c: Context, text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(c).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            textDirection = View.TEXT_DIRECTION_LOCALE
        }

    fun button(c: Context, text: String, onClick: () -> Unit): Button =
        Button(c).apply {
            this.text = text
            isAllCaps = false
            textSize = 13f
            setTextColor(WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = stroked(c, PANEL_LIGHT, 15)
            stateListAnimator = null
            minHeight = dp(c, 46)
            minimumHeight = dp(c, 46)
            setPadding(dp(c, 12), 0, dp(c, 12), 0)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 48))
                .apply { topMargin = dp(c, 6) }
            setOnClickListener { onClick() }
        }

    fun primaryButton(c: Context, text: String, onClick: () -> Unit): Button =
        Button(c).apply {
            this.text = text
            isAllCaps = false
            textSize = 14f
            setTextColor(Color.parseColor("#17241B"))
            typeface = Typeface.DEFAULT_BOLD
            background = gradient(c, intArrayOf(GOLD, Color.parseColor("#C9A75D")), 15)
            stateListAnimator = null
            minHeight = dp(c, 48)
            minimumHeight = dp(c, 48)
            setPadding(dp(c, 16), 0, dp(c, 16), 0)
            setOnClickListener { onClick() }
        }

    fun card(c: Context): LinearLayout =
        LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(c, 16), dp(c, 15), dp(c, 16), dp(c, 15))
            background = stroked(c, PANEL, 20)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = dp(c, 11) }
        }

    fun heroCard(c: Context): LinearLayout =
        LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(c, 19), dp(c, 18), dp(c, 19), dp(c, 18))
            background = gradient(c, intArrayOf(Color.parseColor("#1D3D2D"), Color.parseColor("#10261D"), Color.parseColor("#17251D")), 24)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = dp(c, 13) }
        }

    fun pill(c: Context, text: String, color: Int = GOLD): TextView =
        label(c, text, 11f, color, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(c, 11), dp(c, 6), dp(c, 11), dp(c, 6))
            background = rounded(c, PANEL_RAISED, 30)
        }

    fun input(c: Context, hint: String): EditText = EditText(c).apply {
        this.hint = hint
        setHintTextColor(MUTED)
        setTextColor(WHITE)
        textSize = 14f
        setSingleLine(true)
        textDirection = View.TEXT_DIRECTION_LOCALE
        gravity = Gravity.CENTER_VERTICAL or Gravity.END
        background = stroked(c, PANEL_LIGHT, 15)
        setPadding(dp(c, 15), dp(c, 11), dp(c, 15), dp(c, 11))
    }

    fun sectionTitle(c: Context, text: String): TextView =
        label(c, text, 17f, WHITE, true).apply {
            setPadding(0, dp(c, 15), 0, dp(c, 9))
        }

    fun settingRow(c: Context, title: String, value: TextView, onClick: () -> Unit): View =
        LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            isClickable = true
            isFocusable = true
            background = rounded(c, PANEL, 14)
            setPadding(dp(c, 13), dp(c, 12), dp(c, 13), dp(c, 12))
            val textCol = LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                addView(label(c, title, 14f, WHITE, true))
                value.textSize = 11.5f
                value.setTextColor(MUTED)
                value.maxLines = 1
                value.ellipsize = android.text.TextUtils.TruncateAt.END
                value.setPadding(0, dp(c, 4), 0, 0)
                addView(value, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            addView(label(c, "‹", 25f, GOLD, false).apply { gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(dp(c, 24), ViewGroup.LayoutParams.MATCH_PARENT))
            addView(textCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            setOnClickListener { onClick() }
        }

    fun addDivider(c: Context, parent: LinearLayout) {
        parent.addView(View(c).apply { setBackgroundColor(BORDER) }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 1)
        ).apply {
            topMargin = dp(c, 4)
            bottomMargin = dp(c, 4)
        })
    }

    fun choose(c: Context, title: String, options: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(c)
            .setTitle(title)
            .setItems(options.toTypedArray()) { _, which -> onPick(which) }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
