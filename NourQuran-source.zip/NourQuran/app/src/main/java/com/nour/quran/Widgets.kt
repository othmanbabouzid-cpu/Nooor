package com.nour.quran

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** ويدجت الساعة: ساعة كبيرة وتاريخ والصلاة القادمة. */
class ClockWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) manager.updateAppWidget(id, buildViews(context))
    }

    companion object {
        fun buildViews(c: Context): RemoteViews {
            val views = RemoteViews(c.packageName, R.layout.widget_clock)
            views.setTextViewText(R.id.widgetNext, nextLabel(c))
            val open = PendingIntent.getActivity(
                c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widgetRoot, open)
            return views
        }

        fun updateAll(c: Context) {
            val manager = AppWidgetManager.getInstance(c)
            val ids = manager.getAppWidgetIds(ComponentName(c, ClockWidgetProvider::class.java))
            for (id in ids) manager.updateAppWidget(id, buildViews(c))
        }

        private fun nextLabel(c: Context): String {
            val next = PrayerCache.nextPrayer(PrayerCache.load(c).days, System.currentTimeMillis())
                ?: return "افتح التطبيق لتحديث أوقات الصلاة"
            return "الصلاة القادمة: " + PrayerNames.arabic(next.first) + " " + PrayerCache.clock(next.second)
        }
    }
}

/** ويدجت البحث: شريط بحث يفتح القرآن مباشرة. */
class SearchWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        val views = RemoteViews(context.packageName, R.layout.widget_search)
        val intent = Intent(context, MainActivity::class.java)
            .putExtra(MainActivity.EXTRA_FOCUS_SEARCH, true)
        val pi = PendingIntent.getActivity(
            context, 1, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        views.setOnClickPendingIntent(R.id.searchRoot, pi)
        for (id in appWidgetIds) manager.updateAppWidget(id, views)
    }
}

/** ويدجت آية اليوم: تُجلب مرة في اليوم ثم تُحفظ. */
class DailyAyahWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) manager.updateAppWidget(id, buildViews(context))
        if (!isTodayCached(context)) {
            Thread {
                try {
                    QuranRepository.dailyAyah(context, Prefs.edition(context))
                } catch (_: Exception) {
                    // نعيد المحاولة في التحديث القادم
                }
                updateAll(context)
            }.start()
        }
    }

    companion object {
        private fun stampNow(c: Context): String = Dates.today() + "|" + Prefs.edition(c)

        fun isTodayCached(c: Context): Boolean =
            Prefs.dailyStamp(c) == stampNow(c) && QuranRepository.cachedDaily(c) != null

        fun buildViews(c: Context): RemoteViews {
            val views = RemoteViews(c.packageName, R.layout.widget_daily)
            val daily = if (isTodayCached(c)) QuranRepository.cachedDaily(c) else null
            if (daily != null) {
                views.setTextViewText(R.id.dailyText, daily.text)
                views.setTextViewText(R.id.dailySurah, daily.surahName + " · الآية " + daily.numberInSurah)
                val open = Intent(c, ReaderActivity::class.java)
                    .putExtra(ReaderActivity.EXTRA_SURAH, daily.surahNumber)
                    .putExtra(ReaderActivity.EXTRA_NAME, daily.surahName)
                    .putExtra(ReaderActivity.EXTRA_AYAH, daily.numberInSurah)
                val pi = PendingIntent.getActivity(
                    c, 10, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                views.setOnClickPendingIntent(R.id.dailyRoot, pi)
            } else {
                views.setTextViewText(R.id.dailyText, "جاري تحميل آية اليوم...")
                views.setTextViewText(R.id.dailySurah, "")
            }
            return views
        }

        fun updateAll(c: Context) {
            val manager = AppWidgetManager.getInstance(c)
            val ids = manager.getAppWidgetIds(ComponentName(c, DailyAyahWidgetProvider::class.java))
            for (id in ids) manager.updateAppWidget(id, buildViews(c))
        }
    }
}
