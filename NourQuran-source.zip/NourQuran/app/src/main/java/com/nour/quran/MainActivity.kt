package com.nour.quran

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** نقطة الدخول والتنقل الرئيسي للتطبيق. */
class MainActivity : Activity() {

    private val pages = mutableListOf<View>()
    private val navItems = mutableListOf<LinearLayout>()
    private val navIcons = mutableListOf<TextView>()
    private val navTitles = mutableListOf<TextView>()
    private lateinit var content: FrameLayout
    private lateinit var quranTab: QuranTab
    private lateinit var prayerTab: PrayerTab
    private lateinit var adhkarTab: AdhkarTab
    private lateinit var hadithTab: HadithTab
    private lateinit var settingsTab: SettingsTab

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        quranTab = QuranTab(this)
        prayerTab = PrayerTab(this)
        adhkarTab = AdhkarTab(this)
        hadithTab = HadithTab(this)
        settingsTab = SettingsTab(this) { prayerTab.refresh(true) }
        buildUi()
        ensurePermissions()
        DeviceLocation.update(this)
        prayerTab.refresh(false)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        prayerTab.showPrayers()
        settingsTab.refresh()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun dp(v: Int): Int = Ui.dp(this, v)

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Ui.BG)
            setPadding(0, 0, 0, dp(5))
        }
        root.addView(buildHeader())
        content = FrameLayout(this)
        content.clipChildren = false
        content.clipToPadding = false
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val all = listOf(quranTab.view, prayerTab.view, adhkarTab.view, hadithTab.view, settingsTab.view)
        for (page in all) {
            page.layoutDirection = View.LAYOUT_DIRECTION_RTL
            pages.add(page)
            content.addView(page, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        root.addView(buildTabBar())
        setContentView(root)
        showTab(0)
    }

    private fun buildHeader(): View {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(12), dp(18), dp(11))
        }
        val mark = TextView(this).apply {
            text = "ن"
            textSize = 25f
            typeface = Typeface.SERIF
            setTextColor(Color.parseColor("#17251B"))
            gravity = Gravity.CENTER
            background = Ui.gradient(this@MainActivity, intArrayOf(Ui.GOLD, Color.parseColor("#C6A45C")), 15)
        }
        wrap.addView(mark, LinearLayout.LayoutParams(dp(45), dp(45)))
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(11), 0, 0, 0)
        }
        titleCol.addView(Ui.label(this, "نور القرآن", 19f, Ui.WHITE, true))
        titleCol.addView(Ui.label(this, "رفيقك للقراءة والذكر", 11f, Ui.MUTED))
        wrap.addView(titleCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        wrap.addView(Ui.pill(this, "وِردك اليومي", Ui.GOLD))
        return wrap
    }

    private fun buildTabBar(): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = Ui.stroked(this@MainActivity, Ui.PANEL, 22)
            setPadding(dp(5), dp(5), dp(5), dp(5))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(66))
            lp.setMargins(dp(11), dp(5), dp(11), dp(5))
            layoutParams = lp
        }
        val titles = listOf("القرآن", "الصلاة", "الأذكار", "الحديث", "المزيد")
        val symbols = listOf("۞", "◷", "✧", "≋", "•••")
        for (i in titles.indices) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                background = Ui.rounded(this@MainActivity, Color.TRANSPARENT, 15)
                isClickable = true
                isFocusable = true
                setPadding(dp(2), dp(4), dp(2), dp(3))
                setOnClickListener { showTab(i) }
            }
            val icon = Ui.label(this, symbols[i], if (i == 4) 16f else 19f, Ui.MUTED, true).apply { gravity = Gravity.CENTER }
            val title = Ui.label(this, titles[i], 10f, Ui.MUTED, true).apply { gravity = Gravity.CENTER }
            item.addView(icon)
            item.addView(title)
            outer.addView(item, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                marginStart = dp(2)
                marginEnd = dp(2)
            })
            navItems.add(item)
            navIcons.add(icon)
            navTitles.add(title)
        }
        return outer
    }

    private fun showTab(index: Int) {
        if (index !in pages.indices) return
        for ((i, page) in pages.withIndex()) page.visibility = if (i == index) View.VISIBLE else View.GONE
        if (index == 0) quranTab.refreshMeta()
        if (index == 3) hadithTab.onShown()
        for (i in navItems.indices) {
            val selected = i == index
            navItems[i].background = if (selected) Ui.stroked(this, Ui.PANEL_RAISED, 15, Ui.BORDER) else Ui.rounded(this, Color.TRANSPARENT, 15)
            navIcons[i].setTextColor(if (selected) Ui.GOLD else Ui.MUTED)
            navTitles[i].setTextColor(if (selected) Ui.WHITE else Ui.MUTED)
        }
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra(EXTRA_FOCUS_SEARCH, false) == true) {
            showTab(0)
            quranTab.focusSearch()
        }
    }

    private fun ensurePermissions() {
        val wanted = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            wanted.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        if (wanted.isNotEmpty()) requestPermissions(wanted.toTypedArray(), REQ_PERMS)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERMS && DeviceLocation.update(this)) prayerTab.refresh(true)
    }

    companion object {
        const val EXTRA_FOCUS_SEARCH = "focus_search"
        private const val REQ_PERMS = 201
    }
}
