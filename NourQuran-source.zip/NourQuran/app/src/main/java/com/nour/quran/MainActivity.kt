package com.nour.quran

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout

/** الشاشة الرئيسية: خمسة تبويبات. */
class MainActivity : Activity() {

    private val pages = mutableListOf<View>()
    private val tabButtons = mutableListOf<Button>()
    private lateinit var quranTab: QuranTab
    private lateinit var prayerTab: PrayerTab
    private lateinit var adhkarTab: AdhkarTab
    private lateinit var hadithTab: HadithTab
    private lateinit var settingsTab: SettingsTab

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        quranTab = QuranTab(this)
        prayerTab = PrayerTab(this)
        adhkarTab = AdhkarTab(this)
        hadithTab = HadithTab(this)
        settingsTab = SettingsTab(this) { prayerTab.refresh(true) }
        buildUi()
        ensurePermissions()
        DeviceLocation.update(this)
        prayerTab.refresh(false)
    }

    override fun onResume() {
        super.onResume()
        prayerTab.showPrayers()
        quranTab.refreshContinue()
        settingsTab.refresh()
        // يعيد الجدولة بعد منح صلاحية التنبيه الدقيق من الإعدادات
        PrayerScheduler.scheduleNext(this)
    }

    private fun dp(v: Int): Int = Ui.dp(this, v)

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
        }
        root.addView(
            Ui.label(this, "نور القرآن", 22f, Ui.WHITE, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(12), 0, dp(6))
            }
        )
        val content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val all = listOf(quranTab.view, prayerTab.view, adhkarTab.view, hadithTab.view, settingsTab.view)
        for (page in all) {
            pages.add(page)
            content.addView(page, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        root.addView(buildTabBar())
        setContentView(root)
        showTab(0)
    }

    private fun buildTabBar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(6), dp(4), dp(6), dp(8))
        }
        val titles = listOf("القرآن", "الصلاة", "الأذكار", "الحديث", "الإعدادات")
        for ((i, title) in titles.withIndex()) {
            val b = Ui.button(this, title) { showTab(i) }
            b.textSize = 12f
            tabButtons.add(b)
            bar.addView(
                b,
                LinearLayout.LayoutParams(0, dp(46), 1f).apply {
                    marginStart = dp(2)
                    marginEnd = dp(2)
                }
            )
        }
        return bar
    }

    private fun showTab(index: Int) {
        for ((i, page) in pages.withIndex()) {
            page.visibility = if (i == index) View.VISIBLE else View.GONE
        }
        for ((i, b) in tabButtons.withIndex()) {
            b.background = Ui.rounded(this, if (i == index) Ui.PURPLE else Ui.PANEL_LIGHT, 12)
        }
        if (index == HADITH_TAB) hadithTab.onShown()
    }

    private fun ensurePermissions() {
        val wanted = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            wanted.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (wanted.isNotEmpty()) requestPermissions(wanted.toTypedArray(), REQ_PERMS)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERMS && DeviceLocation.update(this)) {
            prayerTab.refresh(true)
        }
    }

    companion object {
        private const val REQ_PERMS = 201
        private const val HADITH_TAB = 3
    }
}
