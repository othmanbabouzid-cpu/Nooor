package com.nour.quran

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class PrayerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val parsed = PrayerScheduler.parseAction(intent.action) ?: return
        val name = parsed.first
        val isPre = parsed.second
        if (Prefs.prayerEnabled(context, name)) {
            PrayerScheduler.showNotification(context, name, if (isPre) Prefs.preMinutes(context) else null)
        }
        PrayerScheduler.scheduleNext(context)
    }
}

/** بعد إعادة التشغيل أو تغيّر الوقت والمنطقة الزمنية، نعيد جدولة التنبيهات من الكاش. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_TIME_CHANGED -> PrayerScheduler.scheduleNext(context)
        }
    }
}
