package com.nour.quran

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class PrayerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val name = PrayerScheduler.actionToPrayer(intent.action) ?: return
        if (Prefs.prayerEnabled(context, name)) PrayerScheduler.showNotification(context, name)
        PrayerScheduler.scheduleNext(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            PrayerScheduler.scheduleNext(context)
        }
    }
}
