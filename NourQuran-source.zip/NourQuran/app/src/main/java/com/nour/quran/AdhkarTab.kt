package com.nour.quran

import android.app.Activity
import android.content.Intent
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** تبويب الأذكار: عدّاد لكل ذكر، وأدعية قرآنية تفتح في القارئ. */
class AdhkarTab(private val act: Activity) {

    val view: View = build()

    private fun build(): View {
        val scroll = ScrollView(act)
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(act, 14), Ui.dp(act, 8), Ui.dp(act, 14), Ui.dp(act, 20))
        }
        scroll.addView(col)

        for ((title, items) in Adhkar.sections) {
            col.addView(Ui.sectionTitle(act, title))
            for (d in items) col.addView(counterCard(d))
        }

        col.addView(Ui.sectionTitle(act, "أدعية من القرآن"))
        for (ref in Adhkar.quranRefs) {
            col.addView(Ui.button(act, ref.title + "  (" + SurahNames.name(ref.surah) + " " + ref.ayah + ")") {
                act.startActivity(
                    Intent(act, ReaderActivity::class.java)
                        .putExtra(ReaderActivity.EXTRA_SURAH, ref.surah)
                        .putExtra(ReaderActivity.EXTRA_NAME, SurahNames.name(ref.surah))
                        .putExtra(ReaderActivity.EXTRA_AYAH, ref.ayah)
                )
            })
        }
        return scroll
    }

    private fun counterCard(d: Dhikr): View {
        val card = Ui.card(act)
        card.addView(Ui.label(act, d.text, 16f, Ui.WHITE).apply {
            gravity = Gravity.END
            setLineSpacing(0f, 1.4f)
        })
        if (d.note.isNotEmpty()) {
            card.addView(Ui.label(act, d.note, 12f, Ui.MUTED).apply { gravity = Gravity.END })
        }

        val count: TextView = Ui.label(act, "", 15f, Ui.CYAN, true).apply { gravity = Gravity.CENTER }
        fun render() {
            count.text = Prefs.dhikrCount(act, d.id).toString() + " / " + d.target
        }
        render()

        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(
            Ui.button(act, "إعادة") {
                Prefs.setDhikrCount(act, d.id, 0)
                render()
            },
            LinearLayout.LayoutParams(0, Ui.dp(act, 48), 1f).apply { marginEnd = Ui.dp(act, 4) }
        )
        row.addView(count, LinearLayout.LayoutParams(0, Ui.dp(act, 48), 1f))
        row.addView(
            Ui.button(act, "+1") {
                Prefs.setDhikrCount(act, d.id, Prefs.dhikrCount(act, d.id) + 1)
                render()
            },
            LinearLayout.LayoutParams(0, Ui.dp(act, 48), 1f).apply { marginStart = Ui.dp(act, 4) }
        )
        card.addView(row)
        return card
    }
}
