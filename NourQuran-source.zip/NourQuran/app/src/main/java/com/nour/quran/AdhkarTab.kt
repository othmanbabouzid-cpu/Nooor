package com.nour.quran

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView

/** تبويب الأذكار: عدّاد واضح لكل ذكر ومراجع الأدعية القرآنية. */
class AdhkarTab(private val act: Activity) {

    val view: View = build()

    private fun build(): View {
        val scroll = ScrollView(act)
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(Ui.dp(act, 15), Ui.dp(act, 3), Ui.dp(act, 15), Ui.dp(act, 22))
        }
        scroll.addView(col)
        val hero = Ui.heroCard(act)
        hero.addView(Ui.pill(act, "الذكر طمأنينة للقلب", Ui.GOLD))
        hero.addView(Ui.label(act, "اجعل لسانك رطبًا بذكر الله", 21f, Ui.WHITE, true).apply {
            setPadding(0, Ui.dp(act, 10), 0, Ui.dp(act, 4))
        })
        hero.addView(Ui.label(act, "اختر الذكر، وردّده، وسجّل عدد مراتك بضغطة واحدة.", 12f, Ui.MINT))
        col.addView(hero)

        for ((title, items) in Adhkar.sections) {
            col.addView(Ui.sectionTitle(act, title))
            for (d in items) col.addView(counterCard(d))
        }

        col.addView(Ui.sectionTitle(act, "أدعية من القرآن"))
        for (ref in Adhkar.quranRefs) {
            val card = Ui.card(act)
            card.addView(Ui.label(act, ref.title, 15f, Ui.WHITE, true))
            card.addView(Ui.label(act, "${SurahNames.name(ref.surah)} · الآية ${ref.ayah}", 11f, Ui.MUTED).apply {
                setPadding(0, Ui.dp(act, 4), 0, Ui.dp(act, 9))
            })
            card.addView(Ui.button(act, "فتح الآية في المصحف") {
                act.startActivity(Intent(act, ReaderActivity::class.java)
                    .putExtra(ReaderActivity.EXTRA_SURAH, ref.surah)
                    .putExtra(ReaderActivity.EXTRA_NAME, SurahNames.name(ref.surah))
                    .putExtra(ReaderActivity.EXTRA_AYAH, ref.ayah))
            })
            col.addView(card)
        }
        return scroll
    }

    private fun counterCard(d: Dhikr): View {
        val card = Ui.card(act)
        card.addView(Ui.label(act, d.text, 16f, Ui.WHITE, true).apply {
            gravity = Gravity.END
            setLineSpacing(0f, 1.45f)
        })
        if (d.note.isNotEmpty()) {
            card.addView(Ui.label(act, d.note, 11f, Ui.MUTED).apply {
                setPadding(0, Ui.dp(act, 5), 0, 0)
            })
        }
        val count: TextView = Ui.label(act, "", 13f, Ui.GOLD, true).apply { gravity = Gravity.CENTER }
        val progress = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = d.target.coerceAtLeast(1)
            progressTintList = android.content.res.ColorStateList.valueOf(Ui.GOLD)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Ui.PANEL_RAISED)
        }
        fun render() {
            val current = Prefs.dhikrCount(act, d.id)
            count.text = "$current / ${d.target}"
            progress.progress = current.coerceIn(0, d.target)
        }
        render()
        card.addView(count, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 32)))
        card.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(act, 5)).apply {
            bottomMargin = Ui.dp(act, 11)
        })
        val row = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        row.addView(Ui.primaryButton(act, "+  تسبيح") {
            Prefs.setDhikrCount(act, d.id, Prefs.dhikrCount(act, d.id) + 1)
            render()
        }, LinearLayout.LayoutParams(0, Ui.dp(act, 46), 1.35f).apply { marginEnd = Ui.dp(act, 3) })
        row.addView(Ui.button(act, "إعادة") {
            Prefs.setDhikrCount(act, d.id, 0)
            render()
        }, LinearLayout.LayoutParams(0, Ui.dp(act, 46), 0.65f).apply { marginStart = Ui.dp(act, 3) })
        card.addView(row)
        return card
    }
}
